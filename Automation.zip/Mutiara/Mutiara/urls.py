"""Mutiara URL Configuration
Author : rskhandx

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import url
import settings
from django.contrib import admin
from django.contrib.auth import logout
from automation.views import userLoginView,createMutiaraProjectView,createMutiaraTargetsView,createMutiaraPackageView,\
    createMutiaraBuildJobView,createMutiaraFSPDetailsView,createMutiaraPostTestCaseToRQMView,createMutiaraTestPlanView,createMutiaraTestCasesView,showMutiaraProjectsView,showMutiaraTargetView,showMutiaraPackageView,deleteMutiaraProjectView,\
    deleteMutiaraPackageView, deleteMutiaraTargetView,showMutiaraBuildJobView,showMutiaraBuildModuleResultsView,exporttoexcelView,mutiaraTotalTestCasesView,mutiaraFlashJobModelView,mutiaraUEFIJobModelView,mutiaraTestcaseReportsTableView
admin.site.site_header = 'Mutiara Administrator Site'
urlpatterns = [
    url(r'^admin/', admin.site.urls),
    #url(r'^users/login', urls),
    #url(r'^',indexTest),
    #url(r'^index/',indexTest),
    url(r'^logout/$', logout, {'next_page': settings.LOGOUT_REDIRECT_URL}, name='logout'),

    #url(r'createTestplan/',createRQMTC,name='createTestplan'),
    #url(r'postTestCase/',postTestCaseView,name='postTestCase'),    
    #url(r'createTestCase/',createTestCase),
    #url(r'viewDataAsXML/',view_in_xml),
    #url(r'getTestCaseasXML/',getTestCaseasXML),
    #url(r'user/',userView),
    #url(r'project/',projectView),
    #url(r'target/',targetView),    
    #url(r'package/',packageView),
    #url(r'login/',userLogin),
    #url(r'logout/',logout_view),
    #url(r'test/',test), 
    #url(r'buildJob/',createBuildJob,name='buildJob'),   
    url(r'login/',userLoginView),
    url(r'createProject/',createMutiaraProjectView,name="createProject"),
    url(r'showProject/',showMutiaraProjectsView,name="showProject"),
    url(r'deleteProject/',deleteMutiaraProjectView,name="deleteProject"),
    url(r'createTarget/',createMutiaraTargetsView,name="createTarget"),
    url(r'showTarget/',showMutiaraTargetView,name="showTarget"),
    url(r'deleteTarget/',deleteMutiaraTargetView,name="deleteTarget"),
    url(r'createPackage/',createMutiaraPackageView,name="createPackage"),
    url(r'showPackage/',showMutiaraPackageView,name="showPackage"),
    url(r'deletePackage/',deleteMutiaraPackageView,name="deletePackage"),    
    url(r'testalltheModules/',mutiaraTotalTestCasesView,name="testalltheModules"),
    url(r'createBuildJob/',createMutiaraBuildJobView,name="createBuildJob"),    
    url(r'showBuildJob/',showMutiaraBuildJobView,name="showBuildJob"),
    url(r'showBuildModuleResults/',showMutiaraBuildModuleResultsView,name="showBuildModuleResults"),
    url(r'flashTarget',mutiaraFlashJobModelView,name='flashTarget'),
    url(r'uefitestTarget',mutiaraUEFIJobModelView,name='uefitestTarget'),
    url(r'testReport',mutiaraTestcaseReportsTableView,name='testReport'),
    url(r'exporttoExcel/',exporttoexcelView,name="exporttoExcel"),
    url(r'createFSPDetails/',createMutiaraFSPDetailsView,name="createFSPDetails"),
    url(r'createTestCaseInRQM/',createMutiaraPostTestCaseToRQMView,name="createTestCaseInRQM"),
    url(r'createTestPlanInMutiara/',createMutiaraTestPlanView,name='createTestPlanInMutiara'),
    url(r'createMutiaraTestCase/',createMutiaraTestCasesView,name='createMutiaraTestCase'),
    #url(r'validate/',addProject,name="addProject"),    
    #url(r'addTarget/',addTarget,name="addTarget"),
    #url(r'addPackage/',addPackage,name="addPackage"),
    #url(r'packages/',addPackage),    
    #url(r'createpackages/',createPackage,name='createpackages'),
    #url(r'editTarget/',editTarget),
    #url(r'targets/',showTargets,name="showTargets"),
]
