"""
Author : rskhandx
"""

from django import forms
from django.forms import Form,ModelForm
from automation.models import mutiarausers,mutiaraproject,mutiaratargets,mutiarapackage,mutiarabuildjob,mutiarafwdetails,mutiaraposttestcasetorqm,mutiaracreatetestplan,mutiaracreatetestcases,totaltestsuite,mutiaraflashjob,mutiarauefijob,totaltestswithsharepath


class MutiaraUsersForm(forms.Form):    
    username = forms.CharField(max_length=50,label='Enter User Name ')    
    password = forms.CharField(widget=forms.PasswordInput(),label='Password ')    

class createMutiaraUsers(forms.ModelForm):
    class Meta:        
        model = mutiarausers        
        fields=['username','password']
        password = forms.CharField(widget=forms.PasswordInput())

class MutiaraProjectForm(forms.Form):    
    name = forms.CharField(max_length=50,label='Project Name')


class createMutiaraProject(forms.ModelForm):
    class Meta:
        model = mutiaraproject       
        fields=['name']

class MutiaraTargetsForm(forms.Form):        
    CHIOCES_ID = (i.id for i in mutiaraproject.objects.all())
    CHIOCES_PROJECTS =(i.name for i in mutiaraproject.objects.all())
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_PROJECTS))           
    tname = forms.CharField(label='Target Name',max_length=50)
    pname = forms.ChoiceField(label='Project Name',choices=CHOICES,widget = forms.Select)    
    hname = forms.CharField(label = 'Host Name of the Target',max_length=50)
    hostIP = forms.CharField(label='Host IP',max_length=100)
    owner = forms.CharField(label='Owner of Project',max_length=70)
    
class createMutiraTargets(ModelForm):  
    class Meta:        
        model = mutiaratargets        
        fields = ['tname','pname','hname','hostIP','owner']                  

class deleteTargetForm(forms.Form):    
    name = forms.CharField(max_length=50,label='Target Name')
        
class MutiaraPackageForm(Form):
    CHIOCES_ID = (i.id for i in mutiaraproject.objects.all())
    CHIOCES_PROJECTS =(i.name for i in mutiaraproject.objects.all())
    print 'Choices Project ',CHIOCES_PROJECTS
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_PROJECTS))
    TARGETS = (i.id for i in mutiaratargets.objects.all())
    CHOOSE_TARGETS =(i.tname for i in mutiaratargets.objects.all())
    TARGET_CHIOCES = tuple(zip(TARGETS,CHOOSE_TARGETS))    
    projectName = forms.MultipleChoiceField(choices=CHOICES,widget = forms.SelectMultiple)            
    target = forms.MultipleChoiceField(choices=TARGET_CHIOCES,widget = forms.SelectMultiple)    
    build = forms.CharField(label='BIOS Build Information',max_length=200)    
    release = forms.CharField(label='Build Release Information',max_length=200)        
    

class createMutiaraPackage(forms.ModelForm):    
    class Meta:                      
        model = mutiarapackage
        fields = ['projectName','target','build','release']

class deletePackageForm(forms.Form):    
    name = forms.CharField(max_length=20,label='Package ID')


class MutiaraBuildForm(Form):    
    ip = forms.CharField(label= 'IP Address',max_length=100)
    hostName = forms.CharField(label='Build Server Host Name',max_length=100)
    userName = forms.CharField(label='Build Server User Name',max_length=100)
    projects = mutiaraproject.objects.filter().values_list('name', flat=True)    
    projectName = forms.ModelChoiceField(projects)
    targets = mutiaratargets.objects.filter().values_list('tname', flat=True)
    target = forms.ModelChoiceField(targets)

    
class MutiaraCreateBuildServer(forms.ModelForm):
    CHIOCES_NAME = (i.name for i in mutiaraproject.objects.all())
    CHIOCES_ID =(i.id for i in mutiaraproject.objects.all())    
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_NAME))       
    TARGETS = (i.tname for i in mutiaratargets.objects.all())
    TARGETS_ID =(i.id for i in mutiaratargets.objects.all())
    TARGET_CHIOCES = tuple(zip(TARGETS_ID,TARGETS))         
    projectName = forms.ChoiceField(choices=CHOICES,widget = forms.Select)            
    target = forms.ChoiceField(choices=TARGET_CHIOCES,widget = forms.Select)                
    class Meta:
        model = mutiarabuildjob
        fields = ['buildtype','buildServerip','hostname','userName','projectName','target']        

class MutiaraFlashForm(forms.Form):
    CHIOCES_ID = (i.id for i in mutiaraproject.objects.all())
    CHIOCES_PROJECTS =(i.name for i in mutiaraproject.objects.all())
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_PROJECTS))
    TARGETS = (i.tname for i in mutiaratargets.objects.all())
    TARGETS_ID =(i.id for i in mutiaratargets.objects.all())
    TARGET_CHIOCES = tuple(zip(TARGETS_ID,TARGETS))                    
    tname = forms.ChoiceField(label='Target Name',choices=TARGET_CHIOCES,widget = forms.Select)
    pname = forms.ChoiceField(label='Project Name',choices=CHOICES,widget = forms.Select)    
    hname = forms.CharField(label = 'Host Name ',max_length=50)
    uname = forms.CharField(label = 'Host UserName',max_length=50)
    hostIP = forms.CharField(label='Host IP',max_length=100)
    
class MutiaraFlashJobForm(forms.ModelForm):
    CHIOCES_NAME = (i.name for i in mutiaraproject.objects.all())
    CHIOCES_ID =(i.id for i in mutiaraproject.objects.all())    
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_NAME))       
    TARGETS = (i.tname for i in mutiaratargets.objects.all())
    TARGETS_ID =(i.id for i in mutiaratargets.objects.all())
    TARGET_CHIOCES = tuple(zip(TARGETS_ID,TARGETS))         
    projectName = forms.ChoiceField(choices=CHOICES,widget = forms.Select)            
    targetName = forms.ChoiceField(choices=TARGET_CHIOCES,widget = forms.Select)                
    class Meta:
        model = mutiaraflashjob
        fields = ['targetName','projectName','targetHostName','targetHostIP','targetUserName'] 

class mutiaraUEFIForm(forms.Form):
    TARGETS = (i.tname for i in mutiaratargets.objects.all())
    TARGETS_ID =(i.id for i in mutiaratargets.objects.all())
    TARGET_CHIOCES = tuple(zip(TARGETS_ID,TARGETS))
    CHIOCES_ID = (i.id for i in mutiaraproject.objects.all())
    CHIOCES_PROJECTS =(i.name for i in mutiaraproject.objects.all())
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_PROJECTS))           
    tname = forms.ChoiceField(label='Target Name',choices=TARGET_CHIOCES,widget = forms.Select)
    pname = forms.ChoiceField(label='Project Name',choices=CHOICES,widget = forms.Select)    
    hname = forms.CharField(label = 'Host Name of the Target',max_length=50)
    hostIP = forms.CharField(label='Host IP',max_length=100)
    uname = forms.CharField(label = 'Host UserName of the Target',max_length=50)

class MutiaraUefiJobModelForm(forms.ModelForm):
    CHIOCES_NAME = (i.name for i in mutiaraproject.objects.all())
    CHIOCES_ID =(i.id for i in mutiaraproject.objects.all())    
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_NAME))       
    TARGETS = (i.tname for i in mutiaratargets.objects.all())
    TARGETS_ID =(i.id for i in mutiaratargets.objects.all())
    TARGET_CHIOCES = tuple(zip(TARGETS_ID,TARGETS))         
    projectName = forms.ChoiceField(choices=CHOICES,widget = forms.Select)            
    targetName = forms.ChoiceField(choices=TARGET_CHIOCES,widget = forms.Select)                
    class Meta:
        model = mutiarauefijob
        fields = ['targetName','projectName','targetHostName','targetHostIP','targetUserName'] 
    
class MutiaraTestResultsForm(Form):
    CHIOCES_ID = (i.id for i in mutiaraproject.objects.all())
    CHIOCES_PROJECTS =(i.name for i in mutiaraproject.objects.all())
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_PROJECTS))
    TARGETS = (i.id for i in mutiaratargets.objects.all())
    CHOOSE_TARGETS =(i.tname for i in mutiaratargets.objects.all())
    TARGET_CHIOCES = tuple(zip(TARGETS,CHOOSE_TARGETS))
    status = forms.CharField(label='Test Status',max_length=200)

class MutiaraFSPDetailForm(Form):
    CHIOCES_ID = (i.id for i in mutiaraproject.objects.all())
    CHIOCES_PROJECTS =(i.name for i in mutiaraproject.objects.all())
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_PROJECTS))
    projectName = forms.MultipleChoiceField(choices=CHOICES,widget = forms.SelectMultiple)
    TARGETS = (i.id for i in mutiaratargets.objects.all())
    CHOOSE_TARGETS =(i.tname for i in mutiaratargets.objects.all())
    TARGET_CHIOCES = tuple(zip(TARGETS,CHOOSE_TARGETS))
    target = forms.MultipleChoiceField(choices=TARGET_CHIOCES, widget = forms.SelectMultiple)    
    tgtIP = forms.CharField(label='Target IP Address ')
    thn = forms.CharField(max_length=50,label='Target HostName')    
    bldServer = forms.CharField(max_length=50,label='BuildServer HostName')
    bldServerIP = forms.CharField(label='Build Server IP Address ')
    buildPath = forms.CharField(max_length=50,label='Linux BuildPath')
    hhostName = forms.CharField(max_length=50,label='Host Name')
    hhostIP = forms.CharField(label='Host IP Address')
    hSharedPath = forms.CharField(max_length=50,label='Host SharePath')    

class MutiaraCreateFSPDetails(forms.ModelForm):
    class Meta:
        model = mutiarafwdetails
        fields = ['id','projectName','target','tgtIP','thn','bldServer','bldServerIP','buildPath','hhstName','hhstIP','hSharedPath']

class MutiaraTotalTestCasesSharePath(Form):
    CHIOCES_ID = (i.id for i in mutiaraproject.objects.all())
    CHIOCES_PROJECTS =(i.name for i in mutiaraproject.objects.all())
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_PROJECTS))        
    TARGETS = (i.id for i in mutiaratargets.objects.all())
    CHOOSE_TARGETS =(i.tname for i in mutiaratargets.objects.all())
    TARGET_CHOICES = tuple(zip(TARGETS,CHOOSE_TARGETS))    
    projectName = forms.ChoiceField(label='Project Name',choices=CHOICES,widget = forms.Select)
    targetName = forms.ChoiceField(label='Target Name',choices=TARGET_CHOICES,widget = forms.Select)
    buildScriptPath = forms.CharField(label='Build&Compile Script Path')
    flashScriptPath = forms.CharField(label='Flash Script Path')
    firmwarePath = forms.CharField(label='Firmware Script Path')
    testcasePath = forms.CharField(label='TestCases Script Path')

class MutiaraTotalTestsSharePathModelForm(ModelForm):
    CHIOCES_ID = (i.id for i in mutiaraproject.objects.all())
    CHIOCES_PROJECTS =(i.name for i in mutiaraproject.objects.all())
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_PROJECTS))        
    TARGETS = (i.id for i in mutiaratargets.objects.all())
    CHOOSE_TARGETS =(i.tname for i in mutiaratargets.objects.all())
    TARGET_CHOICES = tuple(zip(TARGETS,CHOOSE_TARGETS))    
    projectName = forms.ChoiceField(label='Project Name',choices=CHOICES,widget = forms.Select)
    targetName = forms.ChoiceField(label='Target Name',choices=TARGET_CHOICES,widget = forms.Select)
    class Meta:
        model = totaltestswithsharepath
        fields = ['id','projectName','targetName','buildScriptPath','flashScriptPath','efiScriptPath','OStestCasePath']


class MutiaraTotalTestCasesDetails(forms.ModelForm):
    CHIOCES_ID = (i.id for i in mutiaraproject.objects.all())
    CHIOCES_PROJECTS =(i.name for i in mutiaraproject.objects.all())
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_PROJECTS))        
    TARGETS = (i.id for i in mutiaratargets.objects.all())
    CHOOSE_TARGETS =(i.tname for i in mutiaratargets.objects.all())
    TARGET_CHOICES = tuple(zip(TARGETS,CHOOSE_TARGETS))    
    projectName = forms.ChoiceField(label='Project Name',choices=CHOICES,widget = forms.Select)
    targetName = forms.ChoiceField(label='Target Name',choices=TARGET_CHOICES,widget = forms.Select)
    class Meta:
        model = totaltestsuite
        fields = ['id','projectName','targetName','buildServerHostName','buildServerIP','buildServerUserName','targetHostName','targethostIP','targetUserName']


class MutiaraPostTestCaseToRQMForm(Form):
    title = forms.CharField(label='Title',max_length=100)    
    creator = forms.CharField(label='Creator',max_length=100)
    owner = forms.CharField(label='Owner',max_length=100)
    description = forms.CharField(label='Description', max_length=200,widget=forms.Textarea)
    
class MutiaraCreatePostCaseToRQM(forms.ModelForm):
    class Meta:
        model = mutiaraposttestcasetorqm
        fields = ['id','title','creator','owner','description']

class MutiaraTestPlan(Form):
    CHIOCES_ID = (i.id for i in mutiaraproject.objects.all())
    CHIOCES_PROJECTS =(i.name for i in mutiaraproject.objects.all())
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_PROJECTS))
    projectName = forms.MultipleChoiceField(choices=CHOICES,widget = forms.Select)    
    title = forms.CharField(label='Test Plan Title',max_length=100)

class MutiaraCreateTestPlanModel(forms.ModelForm):
    class Meta:
        model = mutiaracreatetestplan
        fields = ['id','projectName','title']
        
class MutiaraTestCases(forms.Form):
    CHIOCES_ID = (i.id for i in mutiaracreatetestplan.objects.all())
    CHIOCES_PROJECTS =(i.title for i in mutiaracreatetestplan.objects.all())
    CHOICES = tuple(zip(CHIOCES_ID,CHIOCES_PROJECTS))
    module = forms.CharField(label='Module',max_length=100) 
    title = forms.MultipleChoiceField(choices=CHOICES,widget = forms.Select)    
    proceedure = forms.CharField(label='Prodeedure',max_length=2000)
    expectedbehavior = forms.CharField(label='Expected Behavior',max_length=2000)
    pass_criteria = forms.CharField(label='Passing Criteria',max_length=2000)
    creator = forms.CharField(label='Creator',max_length=100)    
    description = forms.CharField(label='Description',max_length=2000,widget=forms.Textarea)
    
class MutiaraCreateTestCases(forms.ModelForm):
    class Meta:
        model = mutiaracreatetestcases
        fields = ['module','title','proceedure','expectedbehavior','pass_criteria','creator','description']
