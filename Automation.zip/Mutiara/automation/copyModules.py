import os

def copyTestFiles():
    buildFileDir = r'C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\Stitching\BlStitchInternal'    
    print 'Build Dir Path', buildFileDir
    os.chdir(buildFileDir)
    a = [name for name in os.listdir(".") if name.endswith(".bin")]
    print a 
    if(len(a)>0):
        for i in a:
            remotebuildDir = 'copy '+i+r' \\PGISGLAB106\Users\Public\Documents\SharedPath\build_dir'
            print remotebuildDir            
            cmd = os.system(remotebuildDir)                    
            print cmd                        
    else:
        print 'Please check the .bin it is not present' 
                
    flashFileDir = r'C:\Users\rskhandx\Desktop\MutiaraRQM\Scripts\Flash'
    print 'Flash Dir Path', flashFileDir
    os.chdir(flashFileDir)
    b = [name for name in os.listdir(".") if name.endswith(".py")]
    print b        
    if(len(b)>0):
        for i in b:
            remoteFlashDir = 'copy '+i+r' \\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir'
            print remoteFlashDir            
            cmd = os.system(remoteFlashDir)                    
            print cmd                        
    else:
        print 'Please check the .py file it is not present'  
            
    efiTestFileDir = r'C:\Users\rskhandx\Desktop\MutiaraRQM\Scripts\EFI'  
    print 'EFI Test Dir Path', efiTestFileDir 
    os.chdir(efiTestFileDir)
    c = [name for name in os.listdir(".") if name.endswith(".py")]
    if(len(c)>0):
        for i in c:
            remoteEFIDir = 'copy '+i+r' \\PGISGLAB106\Users\Public\Documents\SharedPath\efitest_dir'
            print remoteEFIDir            
            cmd = os.system(remoteEFIDir)                    
            print cmd                        
    else:
        print 'Please check the .py file it is not present'

