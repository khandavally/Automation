"""@package docstring
V1.6.3
Note: Only run in Python V2.7
PyTTk provides a fully class-based interface to the TTk network server and
attached devices.

"""

import json
import socket as s
from select import select
import sys
import threading
import base64
from calendar import month_name

selectRead = 1
selectWrite = 2
selectError = 4

class TTkJSONException(Exception):
    pass

class Device(object):
    """A TTk Device

    The device class provides all of TTk's device-level APIs. A physical device
    may not implement all of the APIs, it's up to the developer to determine
    this before making calls that may return "not implemented" exceptions.
    """

    def __init__(self, server, deviceName):
        """Constructor. Requires a Server object and the device's name"""

        self.callLock = threading.Lock()

        ## Server object which owns this device
        self.server = server

        ## This device's serial number/name
        self.deviceName = deviceName

        ## Friendly name for display in client tools. Can be changed by the client.
        self.clientName = deviceName

        ## Status of the last server call to this device
        self.callSuccessful = False

        ## Copy of the last method name called
        self.lastMethod = ''

        ## Result returned by the last call
        self.returnCode = 0

        ## If last call failed, this stores the error string
        self.errorMessage = ''

    def call(self, method, *args):
        """Call a function on the server for this device and parse the response.

        Responses always have at least one element, the return code. Additional
        elements are optional, but the second element in a failed call is an
        error message. We store everything we can locally.

        call() returns a list of result values from the server. result[0]
        is always the pass/fail return code (as an int, 0==success). Other
        values in the list are optional, and vary from call to call.
        """

        self.callLock.acquire()

        result = []

        try:
            # print "Calling method: %s, deviceName: %s, args: %s" % (method, self.deviceName, str(args))
            result = self.server.call(method, self.deviceName, *args)
            self.lastMethod = method
            self.returnCode = 0
            if(result[0] == 0):
                self.callSuccessful = True
                self.errorMessage = ''
            else:
                self.returnCode = result[0]
                self.callSuccessful = False
                if len(result) > 1:
                    self.errorMessage = result[1]
                else:
                    self.errorMessage = ''
        except Exception as err:
            self.callSuccessful = False
            self.returnCode = -1
            self.errorMessage = err.message
            result = [-1, err.message]
        finally:
            self.callLock.release()

        return result


    ##
    ## AC Control methods
    ##

    def getNumSwitches(self):
        """Gets the number of AC switch ports on a device

        Returns (retCode, numPorts)"""
        return self.call("accontrol.getNumSwitches")

    def switchOn(self, switchNum):
        """Turn on the given switch number

        Returns (retCode)"""
        return self.call("accontrol.switchOn", switchNum)

    def switchOff(self, switchNum):
        """Turn off the given switch

        Accepts (switch number)
        Returns (retCode)"""
        return self.call("accontrol.switchOff", switchNum)

    def pulseOff(self, switchNum, offMS):
        """Pulse the given switch off (EXCEUTES ASYNCHRONOUSLY)

        This function will return as soon as the server accepts the call.
        It is up to the calling function to add delay if needed, to wait
        for the pulse to complete.

        Accepts(switch number, milliseconds to pulse off)
        Returns (retCode)"""
        return self.call("accontrol.pulseOff", switchNum, offMS)

    def getStateSwitch(self, switchNum):
        """Retrieve the current state of a switch

        Accepts (switch number)
        Returns (retCode, switchState)"""
        return self.call("accontrol.getStateSwitch", switchNum)

    def acon(self):
        """Turn on all of the AC switches for this device

        Returns (retCode)"""
        return self.call("accontrol.acon")

    def acoff(self):
        """turn off all of the AC switches for this device

        Returns (retCode)"""
        return self.call("accontrol.acoff")

    def ac_on(self, switchNum):
        """Turn on the given AC switch for this device

        Accepts (switch number)
        Returns (retCode)"""
        return self.call("accontrol.ac_on", switchNum)

    def ac_off(self, switchNum):
        """turn off the given AC switch for this device

        Accepts (switch number)
        Returns (retCode)"""
        return self.call("accontrol.ac_off", switchNum)


    ##
    ## Front Panel IO
    ##

    def pushPower(self):
        """Depress the power button. Will stay pressed until you call releasePower.

        Returns (retCode)"""
        return self.call("sysgpio.pushPower")

    def releasePower(self):
        """Release the power button

        Returns (retCode)"""
        return self.call("sysgpio.releasePower")

    def pushReset(self):
        """Depress the reset button. Will stay pressed until you call releaseReset.

        Returns (retCode)"""
        return self.call("sysgpio.pushReset")

    def releaseReset(self):
        """Release the reset button

        Returns (retCode)"""
        return self.call("sysgpio.releaseReset")

    def touchReset(self):
        """Pulse reset for approx 100 ms

        Returns (retCode)"""
        return self.call("sysgpio.touchReset")

    def pulsePower(self, pulseMS):
        """Pulse the power button (ASYNC)

        This function will return as soon as the server accepts the call.
        It is up to the calling function to add delay if needed, to wait
        for the pulse to complete.

        Accepts (milliseconds to pulse)
        Returns (retCode)"""
        return self.call("sysgpio.pulsePower", pulseMS)


    def getFrontPanelStatus(self):
        """Get the status of the front panel power indicator

        Returns (retCode, power [0 == off])"""
        return self.call("sysgpio.getFrontPanelStatus")

    def clearCMOS(self, clrCmosDuration = 0):
        """Clear the CMOS via the CMOS jumper. Consult user guide for hardware implementation.

        Accepts (seconds to clrCmosDuration)
        Returns (retCode)"""
        if(clrCmosDuration > 0):
            return self.call("sysgpio.clearCMOSDuration", clrCmosDuration * 1000)
        else:
            return self.call("sysgpio.clearCMOS")
		
    def getGPIOPort80(self, rxLen):
		"""Get Port80 from platform using the GPIO header.
		
		Returns (retCode)"""
		return self.call("gpio.getGPIOPort80", rxLen)

    def getMCUPort80(self, platformType):
		"""Get Port80 from platform using MCU Card connection
		
		Returns a array of bytes in byte64 format. The first byte is port 80, second is port 81"""
		return self.call("platform.GetPort80", platformType)


    ##
    ## i2c/SMBus
    ##

    def i2cGetNumPorts(self):
        """get number of available i2c ports/domain masters in the control device

        Returns (retCode, number of ports)"""
        return self.call("smbus.GetNumPorts")


    def i2cSetSpeed(self, portNum, speedKHz):
        """Set the speed of an i2c port

        Accepts(i2c port number [0 indexed], speed in KHz [default is 100KHz])
        Returns (retCode)"""
        return self.call("smbus.SetSpeed", portNum, speedKHz)

    def i2cTransfer(self, portNum, addr, txBuffList, rxLen):
        """Execute an i2c write AND/OR read

        Both phases (read/write) are optional. To only write, specify 0
        for rxLen. To only read, pass a 0-length transmit list.

        If the returned list is shorter than the passed rxLen, the master
        received a premature NACK from the device.

        Accepts (i2c port number, i2c 7-bit address, list of bytes to transmit, number of bytes to receive)
        Returns (retCode, list of received bytes)"""

        return self.call("smbus.Transfer", portNum, addr, rxLen, txBuffList)


    ##
    ## SPI Flash
    ##

    def spiInitChips(self):
        """Initialize the SPI bus and read the topology/model data from the chips attached

        This function should be called whenever the chips have changed (or the board has changed).
        Use GetTopology and GetStrings to retrieve the data this function collects.

        Accepts ()
        Returns (retCode)"""
        return self.call("spiFlash.initChips")

    def spiGetTopology(self):
        """Read the SPI device topology previously detected by InitChips

        This function does not send SPI commands to the chips. It only retrieves the data collected
        when InitChips ran.

        The returned list will have len() equal to the number of CS lines for that TTk device (usually 2 or 3),
        and the index address matches the CS address.

        TTk merges all detected chips into a single linear address space starting with CS0 @0x0.
        You should address different CS chips by using the appropriate linear address offset.

        Each item in the list is a dictionary of <string: int>, with these nodes:

        {
            "spi_speed": The maximum speed (in KHz) that this chip will operate in TTk.
            "chip_size": The total number of bytes in this chip.
            "linear_start_address": The linear address where this chip starts.
            "linear_end_address": The last linear address for this chip.
            "jedec_ID": The 4 bytes returned from a JEDEC ID query of the chip.
        }

        Empty CS lines will have jedec_ID==0xffffffff and chip_size==0.

        Accepts ()
        Returns (retCode, [list of chip dictionaries])"""
        return self.call("spiFlash.getDeviceTopology")

    def spiGetStrings(self):
        """Read the SPI device strings previously detected by InitChips

        This function does not send SPI commands to the chips. It only retrieves the data collected
        when InitChips ran.

        Similar to GetTopology, the returned list will have len() equal to the number of CS lines for that
        TTk device (usually 2 or 3), and the index address matches the CS address.

        Each item in the list is a dictionary of <string: string>, with these nodes:

        {
            "manufacturer_name": Chip manufacuturer.
            "model_name": Chip model.
        }

        Empty CS lines will have "Unkown" for values.
        
        Accepts ()
        Returns (retCode, [list of chip dictionaries])"""        
        return self.call("spiFlash.getDeviceStrings")

    def spiErase(self, startAddr, length):
        """Begin erasing a SPI range

        This function will return immediately if the parameters are parsed as valid.
        You must poll the spiStatus() function to determine when the operation is complete at
        the TTk device.

        The address/length may be only a partial chip, whole chip, or many chips.
        
        Accepts (starting linear address, length of erase in bytes)
        Returns (retCode)"""         
        return self.call("spiFlash.erase", startAddr, length)

    def spiWrite(self, startAddr, length, data):
        """Begin writing SPI data

        This function will return immediately if the parameters are parsed as valid.
        You must poll the spiStatus() function to determine when the operation is complete at
        the TTk device.

        "data" is a non-string iterable of bytes to write. The data may span multiple chips.
        "data" may alternately be a base64 encoded string of the bytes.
        
        Accepts (starting linear address, length of write in bytes, iterable of bytes)
        Returns (retCode)"""
        if(type(data) == type('')):
            return self.call("spiFlash.write", startAddr, length, data)
        else:
            return self.call("spiFlash.write", startAddr, length, base64.b64encode(data))
        

    def spiBeginRead(self, startAddr, length):
        """Begin reading SPI data

        This function will return immediately if the parameters are parsed as valid.
        You must poll the spiStatus() function to determine when the operation is complete at
        the TTk device.

        This function DOES NOT return bytes from the SPI chips. It tells TTk to begin
        reading the data into a server buffer. You must use spiReadData to transfer the data
        from the server to the client.

        The length may span multiple chips.
        
        Accepts (starting linear address, length of read in bytes)
        Returns (retCode)"""
        return self.call("spiFlash.beginRead", startAddr, length)

    def spiReadData(self, length):
        """Read data from the server SPI buffer to the client

        This function requires a previous call to spiBeginRead to initiate a read from the SPI
        chips into the server buffer. "length" does not have to match the number of bytes in
        the buffer, but it cannot be more than the current buffer size. For example, you may
        read 64k back to the client at a time, as each 64k accumulates in the buffer. Use
        spiStatus to monitor the buffer contents.

        Accepts (number of bytes to read)
        Returns (retCode)"""

        r = self.call("spiFlash.readData", length)

        if(r[0] == 0):
            # success
            return(0, bytearray(base64.b64decode(r[1])))
        else:
            return r

    def spiStatus(self):
        """Read the operational status of this TTk SPI device

        This is the main polling function for checking the state of operations and status of
        the TTk SPI device. It returns a dictionary of <string: int> values:

        {
            status: 0==idle/done, 1==busy, 2=error (use spiAbort to clear error)
            operation: current or previous operation - 0==idle, 1==read, 2==write, 3==erase, 4==wait, 5=poll
            bytesInReadBuffer: number of bytes in the server buffer available to ReadData
            currentAddress: The current linear address that the TTk device is operating at
        }
        
        A client can generally use currentAddress as a progress indicator to tell when TTk will finish an operation.
        Because of the way some devices operate and buffer, the currentAddress may be inaccurate by up to a
        few "seconds" of operation so you must use "status" to decide when an operation is complete and
        a new one can be started.

        Accepts ()
        Returns ({status dictionary})"""
        return self.call("spiFlash.getStatus")
    
    def spiAbort(self):
        """Abort the current operation, or clear an error

        Accepts ()
        Returns (retCode)"""
        return self.call("spiFlash.abort")

    def spiFlushData(self):
        """Flush the read data buffer on the spi device

        Accepts ()
        Returns (retCode)"""
        return self.call("spiFlash.flushData")    

    def GetSpiSpeed(self):
        """Get manual set SPI Speed

        Returns (retCode, SPI Speed)"""
        return self.call("driverProxy.getSpiSpeed")

    def SetSpiSpeed(self, spiSpeed):
        """Set SPI Speed

        Returns (retCode)"""
        return self.call("driverProxy.setSpiSpeed", spiSpeed)
   
    def GetBiosInfo(self, readData):
        """Get BIOS Information

        Accepts (bytearray of BIOS data)
        Returns (BIOS Information)"""
        #Decode data then remove null byte
        readData = readData.decode('ISO-8859-1').replace('\0','')
        iIndex = readData.rfind('$IBIOSI$')
        BiosInfo = {}
        if iIndex >= 0:
            iIndex+=8
            biosData = readData[iIndex:iIndex+35].split('.')
            BiosInfo['Board_ID']=biosData[0][:7]
            BiosInfo['Board_Rev']=biosData[0][7:8]
            BiosInfo['OEM_ID']=biosData[1]
            BiosInfo['Major_Ver']=biosData[2]
            BiosInfo['Minor_Ver']=biosData[3][1:3]
            BiosInfo['Build_Type']=biosData[3][0:1]
            BiosInfo['CreateDt']=biosData[4][4:6]+" "+\
            month_name[int(biosData[4][2:4])]+" "+\
            biosData[4][0:2]+" "+biosData[4][6:8]+":"+biosData[4][8:10]
        return BiosInfo
    
    def __del__(self):
        self.server = None
        
    ##
    ## GPIO
    ##

    def getGPIO(self, port):
        """Get GPIO signal

        Accepts(Port number which default is 0)
        Returns(Direction[Output = 1 or Input = 0],
        Pin state[High = 1 or Low = 0])"""
        direc = 0
        state = 0
        
        r = self.call("gpio.getMode", port)

        if(r[0] == 0):
            # success
            direc = r[1]            
            r = self.call("gpio.getPins", port)
            
            if(r[0] == 0):
                # success
                state = r[1]           
        
        return(direc, state)

    def setGPIO(self, port, direc, state, bit_position):
        """Set one or more GPIO signal

        Accepts(Port number which default is 0,
        Direction[Output = 1 or Input = 0],
        Pin state[High = 1 or Low = 0],
        Pin position[GPIO0 = 0, GPIO1 = 1 and so on])
        Returns(retCode)"""

        for i in xrange(len(bit_position)):
            bitMask = 0x1 << bit_position[i]
            
            if(direc[i] == 1):
                pinMode = 0x1 << bit_position[i];
            else:
                pinMode = 0;
                
            r = self.call("gpio.setMode", port, bitMask, pinMode)
            
            if(r[0] == 0):
                # success
                if (state[i] == 1):
                    pinMode = 0x1 << bit_position[i];
                    r = self.call("gpio.setPins", port, bitMask, pinMode)
                else:
                    pinMode = 0;
                    r = self.call("gpio.clearPins", port, bitMask, pinMode)
                    
        return r[0]
    
    ##
    ## Device Settings
    ##

    def setDeviceLock(self, lockID):
        """Set Device Lock ID

        Returns (retCode)"""
        return self.call("driverProxy.setDeviceLock", lockID)

    def getDeviceLock(self):
        """Get Device Lock ID

        Returns (retCode, lockID)"""
        return self.call("driverProxy.getDeviceLock")

    def setDeviceUserMessage(self, message):
        """Set Device Lock Message

        Returns (retCode)"""
        return self.call("driverProxy.setDeviceUserMessage", message)

    def getDeviceUserMessage(self):
        """Get Device Lock Message

        Returns (retCode, message)"""
        return self.call("driverProxy.getDeviceUserMessage")    
    
class Server(object):
    """A TTk Server (single IP/host)

    Servers provide access to devices, and can accept API calls directly
    """

    def __init__(self, address="127.0.0.1", connect=True):
        """Create a new server. Provide hostname or IP in address (localhost by default)"""

        self.callLock = threading.Lock()
        self.serverName = address
        self.sockPort = 7170
        self._socket = s.socket(s.AF_INET, s.SOCK_STREAM)
        self.timeout = 30
        self._socket.settimeout(self.timeout)
        self._id = 0

        ## If the last call failed, this contains a string with the error message
        self.lastError= ""

        ## Hostname or IP for this server
        self.serverName

        ## Connection state for this server
        self.connected = False

        if not connect:
            return
        else:
            self.connect()

        # Example: What are the arguments to the driverProxy.setName function?
        # print self.call('system.listParams', 'driverProxy.setClientName')


    def connect(self):
        """(re)connect to the server"""

        if self.connected:
            return True
        try:
            self._socket.connect((self.serverName, self.sockPort))
            self.connected = True
        except:
            self.disconnect()
            return


    def _socketReady(self, type = selectRead):
        readList = []
        writeList = []
        errorList = []
        if(type & selectRead):
            readList.append(self._socket)
        if(type & selectWrite):
            writeList.append(self._socket)
        if(type & selectError):
            errorList.append(self._socket)
        return(select(readList, writeList, errorList, self.timeout))


    def _send(self, method, params=None):
        ready = False
        while not ready:
            ready = self._socketReady(selectWrite)[1]
        output = {}
        output['id'] = self._id
        self._id += 1
        output['method'] = method
        if params:
            output['params'] = params
        outs = json.dumps(output) + '\r'
        #print "sending: " + outs
        self._socket.send(outs)


    def _read(self):
        ready = False
        while not ready:
            ready = self._socketReady(selectRead)[0]
        parsed = False
        data = bytearray()
        while not parsed:
            data.extend(self._socket.recv(4096))
            if not data[-1] == 13:  ### 13 is CR, '\r'
                continue
            try:
                data = str(data)
                parsedData = json.loads(data)
                parsed = True
            except ValueError:
                raise
        if 'error' in parsedData:
            raise TTkJSONException(parsedData['error']['errors'])
        return parsedData['result']


    def _command(self, cmd, *params):
        self._send(cmd, params)
        return self._read()

    def call(self, method, *args):
        """Call a function on the server and parse the response.

        Responses always have at least one element, the return code. Additional
        elements are optional, but the second element in a failed call is an
        error message. Store everything we can.

        call() returns the result list from the server.
        """

        self.callLock.acquire()

        try:
            # print "Calling method: %s, args: %s" % (method, str(args))
            result = self._command(method, *args)
            self.returnCode = 0
            if(result[0] == 0):
                self.callSuccessful = True
                self.errorMessage = ''
            else:
                self.returnCode = result[0]
                self.callSuccessful = False
                if len(result) > 1:
                    self.errorMessage = result[1]
                else:
                    self.errorMessage = ''
        except Exception as err:
            self.callSuccessful = False
            self.returnCode = -1
            result = [-1, err.message]
            self.errorMessage = err.message
        finally:
            self.callLock.release()

        return result

    def listMethods(self):
        """Get a list of all available methods on the server"""
        return self.call("system.listMethods")

    def getDevices(self):
        """Refresh the devices on the server, and return a list of Device objects"""
        result = self.call("driverProxy.listDevices")
        if result[0] is 0:
            self.devices = result[1]
            devList = []
            for dev in self.devices:
                devList.append(Device(self, dev))
            return devList
        else:
            return []

    def listDevices(self):
        """Refresh the devices on the server, and return a list of devices as serial number strings"""
        result = self.call("driverProxy.listDevices")
        if result[0] is 0:
            self.devices = result[1]
            return self.devices
        else:
            return []    
    
    def setTimeout(self, timeout):
        """Set the timeout for all network calls to this server"""
        self.timeout = timeout
        if(self._socket):
            self._socket.settimeout(timeout)

    def disconnect(self):
        """Disconnect from the server"""
 #       print "close called"
        if(self._socket):
            self._socket.close()

    def __del__(self):
        self.disconnect()
