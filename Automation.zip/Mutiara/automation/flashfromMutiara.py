'''
Created on Jun 3, 2018
@author: sys_isgpsv
'''
import subprocess
import os
import time

def checkFilesCopySharedPath():
    os.getcwd()
    epath = r'C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\RunModules\efitest_dir'
    os.chdir(epath)
    a = [name for name in os.listdir(".") if name.endswith(".py")]
    if(len(a)>0):
        for i in a:
            print i
            efiModulesCopytoHost = 'copy '+i+r' \\PGISGLAB106\Users\Public\Documents\SharedPath\efitest_dir'
            print efiModulesCopytoHost            
            cmd = os.system(efiModulesCopytoHost)                    
            print cmd
    fpath = r'C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\RunModules\flash_dir'
    os.chdir(fpath)
    b = [name for name in os.listdir(".") if name.endswith(".py")]
    if(len(b)>0):
        for i in b:
            print i
            flashModulesCopytoHost = 'copy '+i+r' \\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir'
            fcmd = os.system(flashModulesCopytoHost)
            print fcmd                             

def flashTarget(hostName,userName):
    os.getcwd()    
    cmdPowerOff = r'wmic /node:"'+hostName+'"' +' /user:"PGISGLAB106\\'+userName+'" '+'/password:"intel@123" process call create "cmd /c C:\Python27\python.exe \\\PGISGLAB106\Users\Public\Documents\SharedPath\\flash_dir\powerOff.py"'
    print 'WMIC Power Off command... ',cmdPowerOff
    p = subprocess.check_output(cmdPowerOff)
    print 'Target is now power OFF',p    
    time.sleep(10)
    cmdlineFlash = r'wmic /node:"PGISGLAB106" /user:"PGISGLAB106\admin" /password:"intel@123" process call create "cmd /c C:\Python27\python.exe \\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir\flashSUT.py"'
    t = subprocess.check_output(cmdlineFlash)
    print 'Flashing the target is now taking place...',t

def efiTestTargetPO(hostName,userName):
    os.getcwd()
    cmdPowerON=r'wmic /node:"'+hostName+'"' +' /user:"PGISGLAB106\\'+userName+'" '+'/password:"intel@123" process call create "cmd /c C:\Python27\python.exe \\\PGISGLAB106\Users\Public\Documents\SharedPath\\efitest_dir\efiloadShellPO.py"'
    print 'WMIC Power On command...',cmdPowerON
    p = subprocess.check_output(cmdPowerON)
    print 'Target power on navigating to EFI Shell... ',p

def efiTestLeafHIll(hostName,userName):
    os.getcwd()
    cmdPowerON=r'wmic /node:"'+hostName+'"' +' /user:"PGISGLAB106\\'+userName+'" '+'/password:"intel@123" process call create "cmd /c C:\Python27\python.exe \\\PGISGLAB106\Users\Public\Documents\SharedPath\\efitest_dir\efitesting.py"'
    print 'WMIC Power On command...',cmdPowerON
    p = subprocess.check_output(cmdPowerON)
    print 'Target power on navigating to EFI Shell... ',p
