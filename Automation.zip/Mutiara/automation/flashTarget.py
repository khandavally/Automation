import os
import subprocess 
from automation import pyttk
import time

aServer = pyttk.Server('localhost')
## your server may have multiple devices, this code should be updated to get the right device (instead of just first device)
aDevice = aServer.getDevices()[0]

def powerOff():
    ## to get the front panel status
    if  aDevice.getFrontPanelStatus()[1] == 1:
        ## power is on
        print "Original state: FP on"
        print "Attempt to power off. "
        aDevice.pulsePower(5000)
        time.sleep(1)
    while True:
        print aDevice.getFrontPanelStatus()[1]
        break;

def powerOn():
    ## to get the front panel status
    if  aDevice.getFrontPanelStatus()[1] == 1:
        ## power is on
        print "Original state: FP off"
        print "Attempt to power On. "
        print aDevice.getFrontPanelStatus()[1]
        aDevice.acon()
        aDevice.pulsePower(200)
        time.sleep(5)            
    while True:
        break;

def flashSUT():
    binDir = r'\\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir'
    os.chdir(binDir)
    a = [name for name in os.listdir(".") if name.endswith(".bin")]
    if(len(a)>0):
        for i in a:
            flashCmd = 'dpcmd.exe -i -a 0x600000 -u '+i
        print flashCmd
        f = subprocess.check_output(flashCmd)
        output = open(r'flashOutput.txt','r+')
        output.write(f)        
    else:
        print 'Please check the .bin to flash the SUT'

def mainFlash():
    powerOff()
    flashSUT()
    powerOn()
    

    