'''
Created on Jun 3, 2018

@author: sys_isgpsv
'''
import subprocess
import os
import time


f = open(r'flashTarget.txt','w')
def flashTarget():
    os.getcwd()
    cmdPowerOff = r'wmic /node:"PGISGLAB106" /user:"PGISGLAB106\admin" /password:"intel@123" process call create "cmd /c C:\Python27\python.exe \\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir\powerOff.py"'
    p = subprocess.check_output(cmdPowerOff)
    print 'Target is now power OFF',p
    f.write(p)
    time.sleep(10)
    cmdlineFlash = r'wmic /node:"PGISGLAB106" /user:"PGISGLAB106\admin" /password:"intel@123" process call create "cmd /c C:\Python27\python.exe \\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir\flashSUT.py"'
    t = subprocess.check_output(cmdlineFlash)
    print 'Flashing the target is now taking place...',t
    f.write(t)

flashTarget()
