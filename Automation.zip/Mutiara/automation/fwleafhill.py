import subprocess
from subprocess import PIPE,Popen
import os
import datetime
import time

f = open('buildApolloLake.txt','w')

print os.getcwd
def createDirectory():
    os.getcwd()
    a = os.makedirs('APOLLOLAKE_CB_MR4_001_'+str(datetime.datetime.now().strftime('%Y-%m-%d')))
    return a

def untarPackage(filename):
    d = createDirectory()
    os.chdir(d)
    a = [name for name in os.listdir(".") if name.endswith(".tar.gz")]
    if(len(a) !=0):
        p = Popen('tar xvzf '+filename+'.tar.gz',shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        print 'processing the package untar !!!. ',p
        c = p.communicate()
        f.write(str(c))
        return filename   

def checkBSFnFDFiles():
    os.chdir(r'C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\FSPBCT')
    os.getcwd()
    a = [name for name in os.listdir(".") if name.endswith(".bsf")]
    b = [name for name in os.listdir(".") if name.endswith(".fd")]        
    if((a[0]=='Fsp.bsf' and b[0]=='Fsp.fd')):        
        cmd = r'C:\Program Files (x86)\BCT\bct -i Fsp.fd -b Fsp.bsf -o Fsp.rom'
        p = subprocess.check_output(cmd)
        f.write(p)
        return True        
    else:        
        return False

def copyTestFiles():
    buildFileDir = r'C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\Stitching\BlStitchInternal'    
    print 'Build Dir Path', buildFileDir
    os.chdir(buildFileDir)
    a = [name for name in os.listdir(".") if name.endswith(".bin")]
    print a 
    if(len(a)>0):
        for i in a:
            remotebuildDir = 'copy '+i+r' \\PGISGLAB106\Users\Public\Documents\SharedPath\build_dir'
            print remotebuildDir            
            cmd = os.system(remotebuildDir)                    
            print cmd                        
    else:
        print 'Please check the .bin it is not present' 
                
    flashFileDir = r'C:\Users\rskhandx\Desktop\MutiaraRQM\Scripts\Flash'
    print 'Flash Dir Path', flashFileDir
    os.chdir(flashFileDir)
    b = [name for name in os.listdir(".") if name.endswith(".py")]
    print b        
    if(len(b)>0):
        for i in b:
            remoteFlashDir = 'copy '+i+r' \\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir'
            print remoteFlashDir            
            cmd = os.system(remoteFlashDir)                    
            print cmd                        
    else:
        print 'Please check the .py file it is not present'  
            
    efiTestFileDir = r'C:\Users\rskhandx\Desktop\MutiaraRQM\Scripts\EFI'  
    print 'EFI Test Dir Path', efiTestFileDir 
    os.chdir(efiTestFileDir)
    c = [name for name in os.listdir(".") if name.endswith(".py")]
    if(len(c)>0):
        for i in c:
            remoteEFIDir = 'copy '+i+r' \\PGISGLAB106\Users\Public\Documents\SharedPath\efitest_dir'
            print remoteEFIDir            
            cmd = os.system(remoteEFIDir)                    
            print cmd                        
    else:
        print 'Please check the .py file it is not present'
    
def startApolloLakeBuild(user,ip):      
    cbDir = r'C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\Coreboot'
    fspDir = r'C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\FSPBCT'
    stitchDir= r'C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\Stitching\BlStitchInternal\Input'        
    print 'Changing the working directory to Coreboot : ',os.chdir(cbDir)          
    cmd = 'ssh '+user+'@'+ip+' "mkdir /home/sys_isgpsv/'+'APOLLOLAKE_CB_MR4_001_'+str(datetime.datetime.now().strftime('%Y-%m-%d "'))
    print cmd
    f.write(cmd)
    p = subprocess.check_output(cmd)    
    print 'SSH to remote and create a new directory ',p      
    f.write(p)      
    s = 'APOLLOLAKE_CB_MR4_001_'+str(datetime.datetime.now().strftime('%Y-%m-%d'))+' directory has been created on build server '
    f.write(s)    
    ''' checking the .tar.gz file on windows web server '''
    a = [name for name in os.listdir(".") if name.endswith(".tgz")] 
    print 'List of tar.gz files on web server ', a                
    if(len(a)!=0):
        for item in a:
            cp ='scp '+ item+' '+user+'@'+ip+':/home/sys_isgpsv/'+'APOLLOLAKE_CB_MR4_001_'+str(datetime.datetime.now().strftime('%Y-%m-%d'))
            f.write('copy the release package file to remote build server ' )
            f.write(cp)            
            c = Popen(cp,stdout=PIPE, stderr=PIPE)
            out,err = c.communicate()
            f.write('Copy to remote Linux server is in progress please wait : \n')
            f.write(err)
            f.write('Copy to remote build server taking place \n')
            f.write(out)                        
            ut = 'ssh ' +user+'@'+ip+' cd /home/sys_isgpsv/'+'APOLLOLAKE_CB_MR4_001_'+str(datetime.datetime.now().strftime('%Y-%m-%d && tar -xvzf '+item))            
            f.write(ut)
            t = subprocess.check_output(ut)       
            f.write('Untar of the release on Linux is in progress:  ')
            f.write(t)                                                        
            f.write('Untar the package file inside coreboot release package dir is now in progress.. : \n  ')                                
            print 'Changing the working directory to FSPBCT ',os.chdir(fspDir)
            c = checkBSFnFDFiles()
            print c 
            if(c==True):
                r = [name for name in os.listdir(".") if name.endswith(".rom")]
                print 'The .rom files inside the directory ',r
            else:
                print 'Cannot find .rom files inside the directory FSP check .bsf or .fd are present in FSP'
                        
            copyromFile = 'scp '+r[0]+' '+user+'@'+ip+':/home/sys_isgpsv/'+'APOLLOLAKE_CB_MR4_001_'+str(datetime.datetime.now().strftime('%Y-%m-%d/intel/fsp/soc/apllake/bin'))
            print 'Copy .rom file to build server command ',copyromFile
            cpRom = subprocess.check_output(copyromFile)            
            f.write(cpRom)
            print '.rom file from FSP directory from windows is getting copied to build server',cpRom
            mvRomtoFdFile = 'ssh ' +user+'@'+ip+' "cd /home/sys_isgpsv/'+'APOLLOLAKE_CB_MR4_001_'+str(datetime.datetime.now().strftime('%Y-%m-%d/intel/fsp/soc/apllake/bin && mv Fsp.rom Fsp.fd "' ))
            fd = subprocess.check_output(mvRomtoFdFile)            
            f.write('Following are the .fd files on build server : \n')
            f.write(fd)
            cpConfig = 'ssh ' +user+'@'+ip+' "cd /home/sys_isgpsv/'+'APOLLOLAKE_CB_MR4_001_'+str(datetime.datetime.now().strftime('%Y-%m-%d && cp coreboot/config.lfh .config "' ))
            print 'Copy default config file on build server as : cp coreboot/config.lfh .config ',cpConfig                       
            cpConf = subprocess.check_output(cpConfig)
            print 'Config File renamed on build server from config.lfh to .config',cpConf
            f.write(cpConf)
            runMake = 'ssh ' +user+'@'+ip+' "cd /home/sys_isgpsv/'+'APOLLOLAKE_CB_MR4_001_'+str(datetime.datetime.now().strftime('%Y-%m-%d/coreboot && make clean;make "' ))
            print 'Apollolake coreboot make command ',runMake
            f.write(runMake)
            makeRun = subprocess.check_output(runMake)            
            print 'Execute the make command on build server to complete build and compile proceedure ',makeRun
            f.write(makeRun)
            time.sleep(30)
            checkRomFiles = 'ssh '+ user+'@'+ip+' "cd /home/sys_isgpsv/'+'APOLLOLAKE_CB_MR4_001_'+str(datetime.datetime.now().strftime('%Y-%m-%d/coreboot/build && ls *.rom" ' ))
            print 'Checking the .rom files on build server', checkRomFiles            
            chkRom = subprocess.check_output(checkRomFiles)
            print '.rom files in build system  : ',chkRom
            f.write(chkRom)
            out = []
            buff = []
            for c in chkRom:
                if c == '\n':
                    out.append(''.join(buff))
                    buff = []
                else:
                    buff.append(c)
            else:
                if buff:
                    out.append(''.join(buff))
            print out
            f.write(chkRom)            
            #romFilesBuildServer = []
            print 'Change the directory to stitch the .rom file binary: ',os.chdir(stitchDir)
            if(len(out)>0):
                cpRomFiletohost = 'pscp -pw Ekn96G!e '+user+'@'+ip+':/home/sys_isgpsv/'+'APOLLOLAKE_CB_MR4_001_'+str(datetime.datetime.now().strftime('%Y-%m-%d/coreboot/build/*.rom ./'))
                romFilescopy = subprocess.check_output(cpRomFiletohost)
                f.write(romFilescopy)
                print 'rom files copied from build server for stiching using stitching path '+romFilescopy
                stitchPath = r'C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\Stitching\BlStitchInternal'
                os.chdir(stitchPath)  
                os.system('BlStitch.bat /stitch')
                time.sleep(30)
                l = open('Stitch.log','r')
                log = l.read()
                f.write(log)                                                
                binFile = [name for name in os.listdir(".") if name.endswith(".bin")]
                for i in binFile:
                    c = r'C:\Program Files (x86)\GnuWin32\bin\zip -9 Apl_Bx_SPI.zip '+i
                    z = subprocess.check_output(c)                    
                    print 'Final binary compression is in progress...', z
                    f.write(z)
                print 'Leafhill build after stitching and ready to Flash on target ', binFile                
                print 'Stitching process completed now start flash the .bin file to SUT..', 
                time.sleep(10)
                #copyTestFiles()
                print 'Build file copied to the remote windows host to which the SUT is connected from the web server....'               
            else:
                print 'Build does not happen properly'
            return binFile[0] 