from django.contrib import admin
from automation.models import mutiarausers,mutiaraproject,mutiaratargets,mutiarapackage
# Register your models here.

admin.site.register(mutiarausers)
admin.site.register(mutiaraproject)
admin.site.register(mutiaratargets)
admin.site.register(mutiarapackage)