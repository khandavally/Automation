import subprocess
from subprocess import PIPE
import os
import datetime
import time
f = open('buildJobOutput.txt','r+')
fi = open('buildJobOutput.txt','r')

def ipInfo():
    ip = subprocess.check_output('ipconfig')    
    return ip

def createDirectory():
    os.getcwd()
    a = os.makedirs('DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d')))
    return a

def untarPackage(filename):
    d = createDirectory()
    os.chdir(d)
    a = [name for name in os.listdir(".") if name.endswith(".tar.gz")]
    if(len(a) !=0):
        p = subprocess.check_output('tar xvzf '+filename+'.tar.gz')
        print 'processing the package untar !!!. ',p
        return filename   

def checkBSFnFDFiles():
    os.chdir(r'C:\Users\rskhandx\Desktop\MutiaraRQM\DNVAD_FSP_BETA_003_RC1_20180104\Release Package')    
    os.getcwd()
    a = [name for name in os.listdir(".") if name.endswith(".bsf")]
    b = [name for name in os.listdir(".") if name.endswith(".fd")]        
    if((a[0]=='DENVERTON-AD_FSP.bsf' and b[0]=='DENVERTON-AD_FSP.fd')):
        p = subprocess.check_output('bct -i DENVERTON-AD_FSP.fd -b DENVERTON-AD_FSP.bsf -o coreboot.rom')        
        f.write(p)       
        return True
    else:                
        return False

def copyReleasePkgtoBuild(user,ip):    
    os.chdir(r'C:\Users\rskhandx\Desktop\MutiaraRQM')
    os.getcwd()          
    cmd = 'ssh '+user+'@'+ip+' mkdir /home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d'))
    f.write(cmd)
    p = subprocess.check_output(cmd)
    print 'SSH to remote and create a new directory ',p  
    f.write(p)      
    s = 'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d'))+' directory has been created on build server '
    f.write(s)    
    ''' checking the .tar.gz file on windows web server '''
    a = [name for name in os.listdir(".") if name.endswith(".tar.gz")] 
    print 'List of tar.gz files on web server ', a              
    if(len(a)!=0):
        for item in a:
            cp ='scp '+item+' '+user+'@'+ip+':/home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d'))
            f.write('copy the release package file to remote build server ' )
            f.write(cp)            
            c= subprocess.Popen(cp,stdout=PIPE, stderr=PIPE)
            out,err = c.communicate()
            f.write('Copy to remote Linux server is in progress please wait : \n')
            f.write(err)
            f.write('Copy to remote build server taking place \n')
            f.write(out)                        
            ut = 'ssh ' +user+'@'+ip+' cd /home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d && tar -xvzf '+item))            
            f.write(ut)
            t = subprocess.check_output(ut)
            f.write('Untar of the release on Linux is in progress:  ')
            f.write(t)            
            d = 'ssh ' +user+'@'+ip+' "cd /home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d/DNVAD*/Validation/Coreboot/ && tar -xvzf  *.tgz"'))                    
            f.write(d)
            chkdir = subprocess.check_output(d)                                
            f.write('Untar the package file inside coreboot release package dir is now in progress.. : \n  ')
            f.write(chkdir)              
            chkfdFiles = 'ssh ' +user+'@'+ip+ ' "cd /home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d/DNVAD*/Validation/Coreboot/cid_iafw_*/localconfigs/ && ls *.fd "' ))
            fd = subprocess.check_output(chkfdFiles)
            f.write('Following are the .fd files on build server : \n')
            f.write(fd)                        
            return fd
            

def checkFdFilesinLocalConfig(user,ip):
    os.chdir(r'C:\Users\rskhandx\Desktop\MutiaraRQM')
    os.getcwd()        
    cmd = 'ssh '+user+'@'+ip+' mkdir /home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d'))
    print cmd
    f.write(cmd)
    p = subprocess.check_output(cmd)    
    print 'SSH to remote and create a new directory ',p
    f.write(p)        
    s = 'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d'))+' directory has been created on build server '
    f.write(s)
    ''' checking the .tar.gz file on windows web server '''
    a = [name for name in os.listdir(".") if name.endswith(".tar.gz")]    
    #for i in a:
    #    f.write(i)        
    if(len(a)!=0):
        for item in a:
            cp ='scp '+item+' '+user+'@'+ip+':/home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d'))
            f.write('copy the release package file to remote build server ' )
            f.write(cp)            
            c= subprocess.check_output(cp)
            f.write('Copy to remote Linux server is in progress please wait : \n')
            f.write(c)                                    
            ut = 'ssh ' +user+'@'+ip+' "cd /home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d && tar -xvzf "'+item))
            print ut            
            f.write(ut)
            t = subprocess.check_output(ut)
            f.write('Untar of the release on Linux is in progress:  ')
            f.write(t)            
            d = 'ssh ' +user+'@'+ip+' "cd /home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d/DNVAD*/Validation/Coreboot/ && tar -xvzf  *.tgz"'))                    
            f.write(d)
            chkdir = subprocess.check_output(d)                                
            f.write('Untar the package file inside coreboot release package dir is now in progress.. : \n  ')
            f.write(chkdir)              
            files = 'ssh ' +user+'@'+ip+ ' "cd /home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d/DNVAD*/Validation/Coreboot/cid_iafw_*/localconfigs/ && ls *.fd "' ))
            print 'List of .fd files inside localconfig',files
            fd = subprocess.check_output(files)
            print 'List of .fd files on Linux Build Server ',fd    
            fdFiles = open('fdfiles.txt','w')    
            fdFiles.write(fd)
            with open("fdfiles.txt", "r") as fdFiles:
                l = [x.strip() for x in fdFiles.readlines()]
                print 'List of files in Linux Build Server ',l
                print l[0],l[1],l[2],l[3]               
        os.chdir(r'C:\Users\rskhandx\Desktop\MutiaraRQM\DNVAD_FSP_BETA_003_RC1_20180104\Release Package')
        os.getcwd()    
        a = [name for name in os.listdir(".") if name.endswith(".rom")]
        print 'Files that end with .rom on local file system ',a     
        print 'Renamed '+a[0], os.rename(a[0],l[0] )
        print 'Renamed '+a[1], os.rename(a[1], l[1])
        print 'Renamed '+a[2], os.rename(a[2], l[2])
        print 'Renamed '+a[3], os.rename(a[3],l[3])        
        b = [name for name in os.listdir(".") if name.endswith(".fd")]
        print 'List of .fd files in release package after renaming the .rom files ',b
        time.sleep(20)
        cp = 'scp -r '+b[1]+' '+b[2]+' '+b[3]+' '+b[4]+' '+user+'@'+ip+':/home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d/DNVAD*/Validation/Coreboot/cid_iafw_*/localconfigs/ '))
        print 'Copy the files to remote command ', cp    
        cmd = subprocess.check_output(cp)
        print 'Copy .fd files to build server after rename from .rom to .fd and proceed with build process',cmd
        build = 'ssh ' +user+'@'+ip+ ' "cd /home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d/DNVAD*/Validation/Coreboot/cid_iafw_* && make clean && make'))
        buildJob = subprocess.check_output(build)
        print 'Build Process is in progress assuming build tools are already installed ',buildJob
        f.write(buildJob)
        content = f.read()
        print 'Copy the .fd files to build server  ',content
        return content
    else:
        r = 'release package is missing please check the .tar.gz file format of the release package'
        f.write(r)
        context = f.read()
        return context
    
def createROMFileUsingBCT():    
    files = checkBSFnFDFiles()
    if(files == True):
        p = subprocess.check_output('bct -i DENVERTON-AD_FSP.fd -b DENVERTON-AD_FSP.bsf -o coreboot.rom')
        print 'BCT tool generated the .fd files ',p
        return True
    if(files==False):
        print '.rom files not available with the package' 
        return False

def checkFdFiles():
    os.chdir(r'C:\Users\rskhandx\Desktop\MutiaraRQM\DNVAD_FSP_BETA_003_RC1_20180104\Release Package')
    os.getcwd()
    a = [name for name in os.listdir(".") if name.endswith(".fd")]         
    if(len(a)> 0):        
        print 'BCT tool generated .fd files ',a
        return a
    if(len(a)==0):
        print 'BSF and FD files are missing with the release package we cannot proceed to BCT tool stiching '
        return a        

def renameROMFiles(user,ip):
    os.chdir(r'C:\Users\rskhandx\Desktop\MutiaraRQM\DNVAD_FSP_BETA_003_RC1_20180104\Release Package')
    os.getcwd()    
    a = [name for name in os.listdir(".") if name.endswith(".rom")]
    print 'List of .rom files in local directory ', a
    f = checkFdFilesinLocalConfig(user,ip)
    print 'rename the files to .rom as follow ',f 
    if(len(a)> 0):        
        print 'Files that end with .rom on local file system ',a                        
        print 'Renamed '+a[0], os.rename("a[0]", "f[0].fd")
        print 'Renamed '+a[1], os.rename("a[1]", "f[1].fd")
        print 'Renamed '+a[2], os.rename("a[2]", "f[2].fd")
        print 'Renamed '+a[3], os.rename("a[3]", "f[3].fd")        
        b = [name for name in os.listdir(".") if name.endswith(".fd")]
        print 'List of .rom files in release package after renaming it to .rom files ',b                    
        return b
    if(len(a)==0):            
        return False

def copyFdfilestoBuidServerAfterRename(user,ip):
    os.chdir(r'C:\Users\rskhandx\Desktop\MutiaraRQM\DNVAD_FSP_BETA_003_RC1_20180104\Release Package')
    os.getcwd()   
    b = checkFdFilesinLocalConfig(user,ip)
    print 'The renamed files are as followed ' 
    cp = 'scp -r '+b[1]+' '+b[2]+' '+b[3]+' '+b[4]+' '+user+'@'+ip+':/home/sys_isgpsv/'+'DNV_AD_'+str(datetime.datetime.now().strftime('%Y-%m-%d/DNVAD*/Validation/Coreboot/cid_iafw_*/localconfigs/ '))
    print 'Copy the files to remote command ', cp    
    cmd = subprocess.check_output(cp)
    f.write(cp)
    content = f.read()
    print 'Copy the .fd files to build server  ',cmd
    return content

def buildJobProcess(user,ip):    
    checkBSFnFDFiles()      
    checkFdFilesinLocalConfig(user,ip)          
    context = f.read()
    return context

a = buildJobProcess('sys_isgpsv','10.221.109.37')
print a 