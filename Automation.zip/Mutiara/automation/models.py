"""
Author : rskhandx
"""
from django.db import models

# Create your models here.
class mutiarausers(models.Model):
    id = models.AutoField(primary_key=True)
    username=models.CharField(max_length=70)    
    password = models.CharField(max_length=70)
    
class mutiaraproject(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    date = models.DateField(auto_now=True)
        
class mutiaratargets(models.Model):
    id = models.AutoField(primary_key=True)
    tname = models.CharField(max_length=100)
    pname = models.ForeignKey(mutiaraproject)
    hname = models.CharField(max_length=100)
    hostIP = models.CharField(max_length=100)
    owner = models.CharField(max_length=100)    
    date = models.DateField(auto_now=True)           
        
class mutiarapackage(models.Model):        
    id = models.AutoField(primary_key=True)    
    projectName = models.ForeignKey(mutiaraproject) 
    target = models.ForeignKey(mutiaratargets)    
    build = models.CharField(max_length=50)
    release = models.CharField(max_length=50)    
    date = models.DateField(auto_now=True)

class mutiaramodulestestcases(models.Model):
    id = models.AutoField(primary_key=True)
    module = models.CharField(max_length = 100)
    testcaseName = models.CharField(max_length=500)
    description = models.CharField(max_length=500)
    status = models.CharField(max_length=100)
    date = models.DateField(auto_now=True)
     
class mutiarabuildjob(models.Model):
    id = models.AutoField(primary_key=True)
    BUILD_CHOICES = (
        ('DailyBuild', 'DailyBuild'),
        ('NightlyBuild', 'NightlyBuild'),
        ('WeeklyBuild', 'WeeklyBuild'),
        ('SanityBuild', 'SanityBuild'),        
    )               
    buildtype = models.CharField(max_length=100,choices=BUILD_CHOICES)
    buildServerip = models.CharField(max_length=100)
    hostname = models.CharField(max_length=100)
    userName = models.CharField(max_length=100)
    projectName = models.CharField(max_length=100)
    target = models.CharField(max_length=100)
    date = models.DateField(auto_now=True)

class mutiaraflashjob(models.Model):
    id = models.AutoField(primary_key=True)
    targetName = models.CharField(max_length=100)
    projectName = models.CharField(max_length=100)
    targetHostName = models.CharField(max_length=100)
    targetHostIP = models.CharField(max_length=100)
    targetUserName = models.CharField(max_length=100)  
    date = models.DateField(auto_now=True)         

class mutiarauefijob(models.Model):
    id = models.AutoField(primary_key=True)
    targetName = models.CharField(max_length=100)
    projectName = models.CharField(max_length=100)
    targetHostName = models.CharField(max_length=100)
    targetHostIP = models.CharField(max_length=100)
    targetUserName = models.CharField(max_length=100)  
    date = models.DateField(auto_now=True)   
    
class totaltestsuite(models.Model):
    id = models.AutoField(primary_key=True)    
    projectName = models.CharField(max_length=100)
    targetName = models.CharField(max_length=100)
    buildServerHostName = models.CharField(max_length=100)
    buildServerIP = models.CharField(max_length=100)
    buildServerUserName = models.CharField(max_length=100)    
    targetHostName = models.CharField(max_length=100)
    targethostIP = models.CharField(max_length=100)
    targetUserName = models.CharField(max_length=100)  
    date = models.DateField(auto_now=True)

class totaltestswithsharepath(models.Model):
    id = models.AutoField(primary_key=True)
    projectName = models.CharField(max_length=100)
    targetName = models.CharField(max_length=100)
    buildScriptPath = models.CharField(max_length=100)
    flashScriptPath = models.CharField(max_length=100)
    efiScriptPath = models.CharField(max_length=100)
    OStestCasePath = models.CharField(max_length=100)
    date = models.DateField(auto_now=True)
    
     
class mutiarafwdetails(models.Model):
    id = models.AutoField(primary_key=True)
    projectName = models.ForeignKey(mutiaraproject) 
    target = models.ForeignKey(mutiaratargets)       
    tgtIP = models.CharField(max_length=50) 
    thn = models.CharField(max_length=50)
    bldServer = models.CharField(max_length=50)
    bldServerIP = models.CharField(max_length=50)
    buildPath = models.CharField(max_length=50)
    hhstName = models.CharField(max_length=50)
    hhstIP = models.CharField(max_length=50)
    hSharedPath = models.CharField(max_length=50)
    date = models.DateField(auto_now=True)        

class mutiaraposttestcasetorqm(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100)    
    creator = models.CharField(max_length=50)
    owner = models.CharField(max_length=50)
    description = models.CharField(max_length=500)
    date = models.DateField(auto_now=True)  

class mutiaracreatetestplan(models.Model):  
    id = models.AutoField(primary_key=True)  
    projectName = models.CharField(max_length=100)    
    title = models.CharField(max_length=100) 
      
class mutiaracreatetestcases(models.Model):   
    id = models.AutoField(primary_key=True)
    module = models.CharField(max_length=50)
    title = models.CharField(max_length=100)    
    proceedure = models.CharField(max_length=2000)
    expectedbehavior = models.CharField(max_length=2000)
    pass_criteria = models.CharField(max_length=2000)
    creator = models.CharField(max_length=100)    
    description = models.CharField(max_length=2000)
