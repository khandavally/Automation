import serial
import pyttk
import time
"""
## Modify 'localhost' to appropriate hostname if the hardware is not connected to localhost.
"""
aServer = pyttk.Server('localhost')

"""
## your server may have multiple devices, this code should be updated to get the right device (instead of just first device)
"""
aDevice = aServer.getDevices()[0]

def powerOff():
    ## to get the front panel status
    if     aDevice.getFrontPanelStatus()[1] == 1:
        ## power is on
        print "Original state: FP on"
        print "Attempt to power off. "
        aDevice.pulsePower(200)
        time.sleep(1)
    while True:
        print aDevice.getFrontPanelStatus()[1]
        break;

def powerOn():
    ## to get the front panel status
    if     aDevice.getFrontPanelStatus()[1] == 1:
        ## power is on
        print "Original state: FP off"
        print "Attempt to power On. "
        print aDevice.getFrontPanelStatus()[1]
        aDevice.acon()
        aDevice.pulsePower(200)
        time.sleep(5)            
    while True:
        break;

def kbNavigate():    
    powerOff()
    time.sleep(5)
    powerOn()    
    s = serial.Serial('COM3', 115200, timeout=1)                            
    s.write('\x1b\x4f\x51')
    print s.isOpen()
    s.read(10)
    time.sleep(5)        
    ### Down arrow unicode character ###
    s.write('\x1b[B')
    time.sleep(2)
    ### Down arrow unicode character ###
    s.write('\x1b[B')
    time.sleep(2)
    ### Press Enter ###
    s.write('\r')
    time.sleep(2)
    ### Down arrow unicode character ###
    s.write('\x1b[B')
    time.sleep(5)
    ### Press Enter ###
    s.write('\r\n')
    time.sleep(5)
    s.write('date')
    s.write('\r\n')
    time.sleep(5)
    s.read(10)    
    s.write('pci')
    time.sleep(5)
    s.write('\r\n')        
    time.sleep(5)        
    f = open('out.txt', 'w')    
    s.write('exit')
    s.write('\r\n')
    f.write(s.readall())    
    print s.readall()