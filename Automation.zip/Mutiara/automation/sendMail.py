import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email import Encoders
import os

def send_mail(files = []): 
    #os.chdir(r'C:\Users\rskhandx\Downloads') 
    server = 'smtp.intel.com'
    debug = False      
    msg = MIMEMultipart()
    msg['From'] = 'ranganath.sharmax.khandavally@intel.com'
    msg['To'] = 'ranganath.sharmax.khandavally@intel.com'    
    msg['Subject'] = "Coreboot Test Results Report"
    s = 'Hi Team,\nCoreboot build for release XXX has been completed and .bin file is ready to flash and attached the same \n\n\nRegards,\nRanganath Sharma K \n'
    
    s = s.encode("utf-8")
    s = MIMEText(s, 'plain', "utf-8")
    msg.attach(s)
    msg.add_header('Message-ID', 'ranganath.sharmax.khandavally@intel.com')     
    for i in files:
        print i
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(i,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"'
                       % os.path.basename(i))
        msg.attach(part)
    if not debug:
        smtp = smtplib.SMTP(server)
        smtp.sendmail('ranganath.sharmax.khandavally@intel.com','ranganath.sharmax.khandavally@intel.com', msg.as_string())
        smtp.close()
    return msg

