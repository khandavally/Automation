# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='mutiarabuildjob',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('buildtype', models.CharField(max_length=100, choices=[(b'DailyBuild', b'DailyBuild'), (b'NightlyBuild', b'NightlyBuild'), (b'WeeklyBuild', b'WeeklyBuild'), (b'SanityBuild', b'SanityBuild')])),
                ('buildServerip', models.CharField(max_length=100)),
                ('hostname', models.CharField(max_length=100)),
                ('userName', models.CharField(max_length=100)),
                ('projectName', models.CharField(max_length=100)),
                ('target', models.CharField(max_length=100)),
                ('date', models.DateField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='mutiaracreatetestcases',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('module', models.CharField(max_length=50)),
                ('title', models.CharField(max_length=100)),
                ('proceedure', models.CharField(max_length=2000)),
                ('expectedbehavior', models.CharField(max_length=2000)),
                ('pass_criteria', models.CharField(max_length=2000)),
                ('creator', models.CharField(max_length=100)),
                ('description', models.CharField(max_length=2000)),
            ],
        ),
        migrations.CreateModel(
            name='mutiaracreatetestplan',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('projectName', models.CharField(max_length=100)),
                ('title', models.CharField(max_length=100)),
            ],
        ),
        migrations.CreateModel(
            name='mutiaraflashjob',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('targetName', models.CharField(max_length=100)),
                ('projectName', models.CharField(max_length=100)),
                ('targetHostName', models.CharField(max_length=100)),
                ('targetHostIP', models.CharField(max_length=100)),
                ('targetUserName', models.CharField(max_length=100)),
                ('date', models.DateField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='mutiarafwdetails',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('tgtIP', models.CharField(max_length=50)),
                ('thn', models.CharField(max_length=50)),
                ('bldServer', models.CharField(max_length=50)),
                ('bldServerIP', models.CharField(max_length=50)),
                ('buildPath', models.CharField(max_length=50)),
                ('hhstName', models.CharField(max_length=50)),
                ('hhstIP', models.CharField(max_length=50)),
                ('hSharedPath', models.CharField(max_length=50)),
                ('date', models.DateField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='mutiaramodulestestcases',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('module', models.CharField(max_length=100)),
                ('testcaseName', models.CharField(max_length=500)),
                ('description', models.CharField(max_length=500)),
                ('status', models.CharField(max_length=100)),
                ('date', models.DateField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='mutiarapackage',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('build', models.CharField(max_length=50)),
                ('release', models.CharField(max_length=50)),
                ('date', models.DateField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='mutiaraposttestcasetorqm',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('title', models.CharField(max_length=100)),
                ('creator', models.CharField(max_length=50)),
                ('owner', models.CharField(max_length=50)),
                ('description', models.CharField(max_length=500)),
                ('date', models.DateField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='mutiaraproject',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('name', models.CharField(max_length=50)),
                ('date', models.DateField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='mutiaratargets',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('tname', models.CharField(max_length=100)),
                ('hname', models.CharField(max_length=100)),
                ('hostIP', models.CharField(max_length=100)),
                ('owner', models.CharField(max_length=100)),
                ('date', models.DateField(auto_now=True)),
                ('pname', models.ForeignKey(to='automation.mutiaraproject')),
            ],
        ),
        migrations.CreateModel(
            name='mutiarauefijob',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('targetName', models.CharField(max_length=100)),
                ('projectName', models.CharField(max_length=100)),
                ('targetHostName', models.CharField(max_length=100)),
                ('targetHostIP', models.CharField(max_length=100)),
                ('targetUserName', models.CharField(max_length=100)),
                ('date', models.DateField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='mutiarausers',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('username', models.CharField(max_length=70)),
                ('password', models.CharField(max_length=70)),
            ],
        ),
        migrations.CreateModel(
            name='totaltestsuite',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('projectName', models.CharField(max_length=100)),
                ('targetName', models.CharField(max_length=100)),
                ('buildServerHostName', models.CharField(max_length=100)),
                ('buildServerIP', models.CharField(max_length=100)),
                ('buildServerUserName', models.CharField(max_length=100)),
                ('targetHostName', models.CharField(max_length=100)),
                ('targethostIP', models.CharField(max_length=100)),
                ('targetUserName', models.CharField(max_length=100)),
                ('date', models.DateField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='totaltestswithsharepath',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True)),
                ('projectName', models.CharField(max_length=100)),
                ('targetName', models.CharField(max_length=100)),
                ('buildScriptPath', models.CharField(max_length=100)),
                ('flashScriptPath', models.CharField(max_length=100)),
                ('efiScriptPath', models.CharField(max_length=100)),
                ('OStestCasePath', models.CharField(max_length=100)),
                ('date', models.DateField(auto_now=True)),
            ],
        ),
        migrations.AddField(
            model_name='mutiarapackage',
            name='projectName',
            field=models.ForeignKey(to='automation.mutiaraproject'),
        ),
        migrations.AddField(
            model_name='mutiarapackage',
            name='target',
            field=models.ForeignKey(to='automation.mutiaratargets'),
        ),
        migrations.AddField(
            model_name='mutiarafwdetails',
            name='projectName',
            field=models.ForeignKey(to='automation.mutiaraproject'),
        ),
        migrations.AddField(
            model_name='mutiarafwdetails',
            name='target',
            field=models.ForeignKey(to='automation.mutiaratargets'),
        ),
    ]
