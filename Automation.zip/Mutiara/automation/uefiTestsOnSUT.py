'''
Created on Jun 3, 2018

@author: sys_isgpsv
'''
import os
import subprocess

f = open(r'uefiTestsOnTarget.txt','w')
def uefiLoadShell():
    os.getcwd()
    efiPowerOn = r'wmic /node:"PGISGLAB106" /user:"PGISGLAB106\admin" /password:"intel@123" process call create "cmd /c C:\Python27\python.exe \\PGISGLAB106\Users\Public\Documents\SharedPath\efitest_dir\efipowerON.py"'
    p = subprocess.check_output(efiPowerOn)
    print 'Target is now power On',p
    print 'UEFI Testing is in progress....'
    f.write(p)        

def uefiTestOnLeafHill():    
    os.getcwd()
    efiShell = r'wmic /node:"PGISGLAB106" /user:"PGISGLAB106\admin" /password:"intel@123" process call create "cmd /c C:\Python27\python.exe \\PGISGLAB106\Users\Public\Documents\SharedPath\efitest_dir\efitesting.py"'
    p = subprocess.check_output(efiShell)
    print 'Target now enter the UEFI shell..',p
    print 'UEFI Testing is in progress....'
    f.write(p) 

uefiLoadShell()