"""
Author : rskhandx
"""
from django.shortcuts import render,HttpResponse
from django.contrib import messages
from automation.forms import MutiaraUsersForm,createMutiaraUsers,MutiaraProjectForm,createMutiaraProject,\
    MutiaraTargetsForm, createMutiraTargets, MutiaraPackageForm,deletePackageForm,\
    createMutiaraPackage,MutiaraCreateBuildServer,MutiaraFSPDetailForm,MutiaraCreateFSPDetails,MutiaraCreatePostCaseToRQM,MutiaraCreateTestPlanModel,MutiaraTestPlan,MutiaraTestCases,MutiaraCreateTestCases,\
    MutiaraTotalTestCasesDetails, MutiaraFlashForm,mutiaraUEFIForm,MutiaraFlashJobForm,MutiaraUefiJobModelForm
import django_excel as excel
from sendMail import send_mail
from automation.models import mutiaraproject,mutiaratargets,mutiarapackage,mutiarabuildjob,mutiaramodulestestcases
import os
import subprocess
import time
import itertools
from datetime import datetime
from fwleafhill import startApolloLakeBuild
from flashfromMutiara import flashTarget,efiTestTargetPO,efiTestLeafHIll


def userLoginView(request): 
    f = MutiaraUsersForm(request.POST)
    mf = createMutiaraUsers(request.POST)
    if(request.method) == 'POST':               
        if f.is_valid():
            #mf.save()
            return render(request,'testingIndex.html',{'form':mf})        
    return render(request,'createUser.html',{'form':f})

def createMutiaraProjectView(request):        
    form = MutiaraProjectForm(request.POST)    
    mform = createMutiaraProject(request.POST)
    name = request.POST.get('name')    
    if request.method == 'POST':
        if mform.is_valid():
            a = mutiaraproject.objects.filter(name=name).all()            
            if(len(a)==int(0)):
                mform.save()
                mform = createMutiaraProject
                messages.success(request, 'Project Created successfully')
                return render(request,'testingIndex.html',{'form':mform})
            if(len(a)>int(0)):
                messages.success(request, 'Project name already exists in database create project with an another name. \n')                
                return render(request,'testingIndex.html',{'form':mform})                
        else:
            return HttpResponse('Form is not valid')
    return render(request,'createProject.html',{'form':form})

def showMutiaraProjectsView(request):
    i = []
    j = []
    k = []
    cd = {} 
    p = mutiaraproject.objects.all()
    for items in p:
        i.append(items.id)     
        cd['id']=i
        j.append(items.name)
        cd['name']=j
        k.append(items.date)
        cd['date']=k        
    return render(request,'showProjects.html',cd) 

def deleteMutiaraProjectView(request):        
    form = MutiaraProjectForm(request.POST)    
    mform = createMutiaraProject(request.POST)    
    if request.method == 'POST':
        if mform.is_valid():
            name = request.POST.get('name')
            print name
            instance = mutiaraproject.objects.get(name=name)
            print instance
            instance.delete()                        
            return render(request,'testingIndex.html',{'form':form})
        else:
            return HttpResponse('Form is not valid')
    return render(request,'deleteProject.html',{'form':form})

def createMutiaraTargetsView(request):        
    form = MutiaraTargetsForm(request.POST)    
    mform = createMutiraTargets(request.POST)
    tname = request.POST.get('tname')    
    if request.method == 'POST':
        if mform.is_valid():
            a = mutiaratargets.objects.filter(tname=tname).all()
            if(len(a)==int(0)):
                mform.save()
                mform = createMutiraTargets
                messages.success(request, 'Target Created successfully')
                return render(request,'testingIndex.html',{'form':mform})
            if(len(a)>int(0)):
                messages.success(request, 'Target name already exists in database create target with an another name. \n')                
                return render(request,'testingIndex.html',{'form':mform})                            
        else:
            return HttpResponse('Form is not valid')
    return render(request,'createTargets.html',{'form':form})

def showMutiaraTargetView(request):
    h = []
    i = []
    j = []
    k = []
    l = []
    m = []    
    d = []
    cd = {} 
    p = mutiaratargets.objects.all()

    for items in p:
        h.append(items.id)     
        cd['id']= h
        i.append(items.tname)     
        cd['tname']=i
        j.append(items.pname)
        cd['pname']=j
        k.append(items.hname)
        cd['hname']=k 
        l.append(items.hostIP)    
        cd['hostIP']=l
        m.append(items.owner)
        cd['owner']=m        
        d.append(items.date)
        cd['date']=d          
    return render(request,'showTarget.html',cd) 

def deleteMutiaraTargetView(request):        
    form = MutiaraProjectForm(request.POST)    
    mform = createMutiaraProject(request.POST)    
    if request.method == 'POST':
        if mform.is_valid():
            tname = request.POST.get('tname')
            print tname
            instance = mutiaratargets.objects.get(name=tname)
            print instance
            instance.delete()                        
            return render(request,'testingIndex.html',{'form':form})
        else:
            return HttpResponse('Form is not valid')
    return render(request,'deleteTarget.html',{'form':form})

def createMutiaraPackageView(request):        
    form = MutiaraPackageForm(request.POST)    
    mform = createMutiaraPackage(request.POST)    
    if request.method == 'POST':
        if mform.is_valid():
            mform.save()
            mform = createMutiaraPackage
            return render(request,'testingIndex.html',{'form':mform})
        else:
            return HttpResponse('Form is not valid')
    return render(request,'createPackages.html',{'form':form})

def showMutiaraPackageView(request):
    i = []
    j = []
    k = []
    l = []
    m = []
    d = []
    cd = {} 
    p = mutiarapackage.objects.all()
    for items in p:
        i.append(items.id)     
        cd['id']=i
        j.append(items.projectName)
        cd['projectName']=j
        k.append(items.target)
        cd['target']=k 
        l.append(items.build )    
        cd['build']=l        
        m.append(items.release )    
        cd['release']=m        
        d.append(items.date)
        cd['date']=d          
    return render(request,'showPackage.html',cd) 

def deleteMutiaraPackageView(request):        
    form = deletePackageForm(request.POST)    
    mform = createMutiaraPackage(request.POST)    
    if request.method == 'POST':
        if mform.is_valid():                
            instance = mutiarapackage.objects.get(id=id)            
            instance.delete()                        
            return render(request,'testingIndex.html',{'form':form})
        else:
            return HttpResponse('Form is not valid')
    return render(request,'deletePackage.html',{'form':form})

def fsptestAllModulesJobView(request):
    form = MutiaraProjectForm(request.POST)
    return render(request,'fsptestAllModules.html',{'form':form})

def createMutiaraBuildJobView(request):        
    mform = MutiaraCreateBuildServer(request.POST)    
    if request.method == 'POST':
        context_dict = {}
        if mform.is_valid():                        
            ip = request.POST.get('buildServerip')            
            hostName = request.POST.get('hostname')            
            userName = request.POST.get('userName')
            projectName = request.POST.get('projectName')
            target = request.POST.get('target')
            print 'View Build Job', projectName,target   
            print 'View Build Job IP etc', ip,hostName,userName                   
            mform.save()
            mform = MutiaraCreateBuildServer                            
            #cprelease = buildJobProcess(userName,ip)                        
            cprelease= startApolloLakeBuild(userName,ip)                                
            context_dict['cprelease'] = cprelease
            f = open(r'C:\Users\rskhandx\Documents\Workspace\Mutiara\buildApolloLake.txt','r') 
            buildLogOutput = f.readlines()
            time.sleep(60)
            context_dict['buildLogOutput'] = buildLogOutput    
            files = [name for name in os.listdir(".") if name.endswith(".zip")]
            send_mail(files)                                                                     
            return render(request,'createBuildJobLog.html',context_dict)                                                  
        else:
            return HttpResponse('Form is not valid')
    return render(request,'createBuildJob.html',{'form':mform})

def showMutiaraBuildJobView(request):
    i = []
    j = []
    k = []
    l = []
    m = []
    d = []
    e = []
    f = []
    cd = {} 
    p = mutiarabuildjob.objects.all()
    for items in p:
        i.append(items.id)     
        cd['id']=i
        j.append(items.buildtype)
        cd['buildtype']=j
        k.append(items.buildServerip)
        cd['buildServerip']=k 
        l.append(items.hostname )    
        cd['hostname']=l        
        m.append(items.userName )    
        cd['userName']=m        
        d.append(items.projectName)
        cd['projectName']=d   
        e.append(items.target)
        cd['target']=e
        f.append(items.date)
        cd['date']=f       
    return render(request,'showBuildJobs.html',cd) 

def showMutiaraBuildModuleResultsView(request):
    i = []
    j = []
    k = []
    l = []
    m = []
    d = []    
    cd = {} 
    p = mutiaramodulestestcases.objects.all()
    for items in p:
        i.append(items.id)     
        cd['id']=i
        j.append(items.module)
        cd['module']=j
        k.append(items.testcaseName)
        cd['testcaseName']=k 
        l.append(items.description )    
        cd['description']=l        
        m.append(items.status )    
        cd['status']=m        
        d.append(items.date)
        cd['date']=d               
    return render(request,'showBuildJobResults.html',cd) 

def mutiaraFlashJobView(request):
    form = MutiaraFlashForm(request.POST)
    mform = MutiaraFlashJobForm(request.POST)
    context = {}
    if request.method == 'POST':
        hostName = request.POST.get('hname')
        userName = request.POST.get('uname')
        flash = flashTarget(hostName,userName)
        print flash
        time.sleep(20)          
        f = open(r'\\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir\flashOutput.txt','r')    
        file_contents = f.readlines() 
        context['file_contents'] = file_contents
        context['form'] = form           
        f.close()        
        return render(request,'flashTargetLog.html',context)                
    else:
        return render(request,'flashTarget.html',{'form':form})

def mutiaraFlashJobModelView(request):    
    mform = MutiaraFlashJobForm(request.POST)
    context = {}
    if (request.method == "POST"):
        if mform.is_valid():            
            hostName = request.POST.get('targetHostName')
            userName = request.POST.get('targetUserName')
            flash = flashTarget(hostName,userName)
            print flash
            time.sleep(60)    
            f = open(r'\\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir\flashOutput.txt','r')    
            file_contents = f.readlines() 
            context['file_contents'] = file_contents      
            f.close()
            context['form']=mform
            mform.save()
            return render(request,'flashTargetLog.html',context)
        else:
            return HttpResponse('Form is not valid ...!!!')
    else:
        return render(request,'flashTarget.html',{'form':mform})

def mutiaraUEFIJobModelView(request):
    mform = MutiaraUefiJobModelForm(request.POST)
    context = {}
    if (request.method == "POST"):
        if mform.is_valid():
            hostName = request.POST.get('targetHostName')
            userName = request.POST.get('targetUserName')
            flash = flashTarget(hostName,userName)
            print flash
            time.sleep(60)
            uefiTest = efiTestTargetPO(hostName,userName)
            print uefiTest
            time.sleep(60)
            efiNavigate = efiTestLeafHIll(hostName, userName)   
            print efiNavigate 
            time.sleep(60)
            k = open(r'\\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir\flashOutput.txt','r')
            flash_content = k.readlines()            
            time.sleep(30)
            f = open(r'\\PGISGLAB106\Users\Public\Documents\SharedPath\efitest_dir\out.txt','r')    
            file_contents = f.readlines()
            time.sleep(30)
            context['flash_content']=flash_content 
            context['file_contents'] = file_contents
            context['form'] = mform           
            f.close()
            mform.save()
            return render(request,'uefiTestTargetLog.html',context)                
        else:
            return HttpResponse('Form is invalid..!!!')
    else:
        return render(request,'uefiTestTarget.html',{'form':mform})        

def mutiaraUEFIJobView(request):
    form = mutiaraUEFIForm(request.POST)
    mform = MutiaraUefiJobModelForm(request.POST)
    context = {}
    if request.method == 'POST':
        hostName = request.POST.get('hname')
        userName = request.POST.get('uname')
        flash = flashTarget(hostName,userName)
        print flash
        time.sleep(60)
        uefiTest = efiTestTargetPO(hostName,userName)
        print uefiTest
        time.sleep(60)
        efiNavigate = efiTestLeafHIll(hostName, userName)   
        print efiNavigate 
        time.sleep(100)
        k = open(r'\\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir\flashOutput.txt','r')
        flash_content = k.readlines()
        context['flash_content']=flash_content
        time.sleep(10)
        f = open(r'\\PGISGLAB106\Users\Public\Documents\SharedPath\efitest_dir\out.txt','r')    
        file_contents = f.readlines() 
        context['file_contents'] = file_contents
        context['form'] = form           
        f.close()        
        return render(request,'uefiTestTargetLog.html',context)                
    else:
        return render(request,'uefiTestTarget.html',{'form':form})


def mutiaraTotalTestCasesView(request):
    mform = MutiaraTotalTestCasesDetails(request.POST)
    context = {}
    if (request.method == "POST"):
        if mform.is_valid():
            buildServerUserName = request.POST.get('buildServerUserName')
            buildServerIP = request.POST.get('buildServerIP')            
            buildJob = startApolloLakeBuild(buildServerUserName, buildServerIP)
            print buildJob
            time.sleep(180)
            buildFileDir = r'C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\Stitching\BlStitchInternal'    
            print 'Build Dir Path', buildFileDir
            os.chdir(buildFileDir)
            a = [name for name in os.listdir(".") if name.endswith(".bin")]
            print a 
            if(len(a)>0):
                for i in a:
                    remotebuildDir = 'copy '+i+r' \\PGISGLAB106\Users\Public\Documents\SharedPath\build_dir'
                    print remotebuildDir            
                    cmd = os.system(remotebuildDir)                    
                    print cmd                        
            else:
                print 'Please check the .bin it is not present' 
            time.sleep(10)
            hostName = request.POST.get('targetHostName')
            userName = request.POST.get('targetUserName')
            flash = flashTarget(hostName,userName)
            print flash
            time.sleep(60)
            uefiTest = efiTestTargetPO(hostName,userName)
            print uefiTest
            time.sleep(60)
            efiNavigate = efiTestLeafHIll(hostName, userName)   
            print efiNavigate 
            time.sleep(60)
            b = open(r'C:\Users\rskhandx\Documents\Workspace\Mutiara\buildApolloLake.txt','r')
            build_content = b.readlines()
            context['build_content'] = build_content
            time.sleep(30)
            k = open(r'\\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir\flashOutput.txt','r')
            flash_content = k.readlines()            
            time.sleep(30)
            f = open(r'\\PGISGLAB106\Users\Public\Documents\SharedPath\efitest_dir\efiOutput.txt','r')    
            file_contents = f.readlines()
            time.sleep(30)
            context['flash_content']=flash_content 
            context['file_contents'] = file_contents
            context['form'] = mform           
            f.close()
            mform.save()
            time.sleep(40)
            buildLogTxt = r'xcopy C:\Users\rskhandx\Documents\Workspace\Mutiara\buildApolloLake.txt C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\Stitching\BlStitchInternal'
            os.system(buildLogTxt)
            flashLogTxt = r'xcopy \\PGISGLAB106\Users\Public\Documents\SharedPath\flash_dir\flashOutput.txt C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\Stitching\BlStitchInternal' 
            os.system(flashLogTxt)
            time.sleep(10)
            uefiLogTxt = r'xcopy \\PGISGLAB106\Users\Public\Documents\SharedPath\efitest_dir\efiOutput.txt C:\Users\rskhandx\Desktop\MutiaraRQM\LeafHill\Stitching\BlStitchInternal' 
            os.system(uefiLogTxt)
            time.sleep(5)
            files = [name for name in os.listdir(".") if name.endswith(".zip")]
            txtFiles = [name for name in os.listdir(".") if name.endswith(".txt")]
            logFiles = [name for name in os.listdir(".") if name.endswith(".log")]                                               
            i = itertools.chain(files,txtFiles,logFiles)
            sendFiles = list(i)
            send_mail(sendFiles)                                                   
            return render(request,'totalTestCasesLog.html',context)                
        else:
            return HttpResponse('Form is invalid..!!!')
    else:
        return render(request,'totalTestCases.html',{'form':mform})        


def mutiaraTestcaseReportsTableView(request):
    context = {}
    fname = ['Sharma','Ranga','nath']
    context['fname']=fname       
    lname = ['kahdnavally','ranga']
    context['lname']=lname
    email = ['krnsharma@gmail.com']
    context['email']= email
    return render(request,'showTestResultsTable.html',context)


def mutiaraCompletetestcasesJobView(request):
    #form = MutiaraTotalTestCases(request.POST)    
    mform = MutiaraTotalTestCasesDetails(request.POST)
    if request.method == 'POST':
        if mform.is_valid():            
            a = mutiaraproject.objects.values_list('name')            
            print list(a)                        
            mform.save()
            return render(request,'testingIndex.html',{'form':mform})
        else:
            return HttpResponse('Form is not valid')
    return render(request,'fsptestAllModules.html',{'form':mform})

def exporttoexcelView(request):        
    response = excel.make_response_from_a_table(mutiaramodulestestcases, 'xls')        
    response['Content-Disposition'] = 'attachment; filename="CorebootnFlash.xls"'                 
    return response  

def createMutiaraFSPDetailsView(request):        
    form = MutiaraFSPDetailForm(request.POST)    
    mform = MutiaraCreateFSPDetails(request.POST)    
    if request.method == 'POST':
        if mform.is_valid():
            mform.save()                        
            return render(request,'testingIndex.html',{'form':mform})
        else:
            return HttpResponse('Form is not valid')
    return render(request,'createFSPDetails.html',{'form':form})


def createRQMTestCaseUtility(title,creator,owner):
    os.chdir(r'C:\Users\rskhandx\Documents\Workspace\Mutiara\automation\rqmutility')
    f = open('testcaseCreate.xml','w')
    now = datetime.now() 
    s = '''<?xml version="1.0" encoding="UTF-8"?><ns2:testcase xmlns:ns2="http://jazz.net/xmlns/alm/qm/v0.1/" xmlns:ns1="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:ns3="http://schema.ibm.com/vega/2008/" xmlns:ns4="http://purl.org/dc/elements/1.1/" xmlns:ns5="http://jazz.net/xmlns/prod/jazz/process/0.6/" xmlns:ns6="http://jazz.net/xmlns/alm/v0.1/" xmlns:ns7="http://purl.org/dc/terms/" xmlns:ns8="http://jazz.net/xmlns/alm/qm/v0.1/testscript/v0.1/" xmlns:ns9="http://jazz.net/xmlns/alm/qm/v0.1/executionworkitem/v0.1" xmlns:ns10="http://open-services.net/ns/core#" xmlns:ns11="http://open-services.net/ns/qm#" xmlns:ns12="http://jazz.net/xmlns/prod/jazz/rqm/process/1.0/" xmlns:ns13="http://www.w3.org/2002/07/owl#" xmlns:ns14="http://jazz.net/xmlns/alm/qm/qmadapter/v0.1" xmlns:ns15="http://jazz.net/xmlns/alm/qm/qmadapter/task/v0.1" xmlns:ns16="http://jazz.net/xmlns/alm/qm/v0.1/executionresult/v0.1" xmlns:ns17="http://jazz.net/xmlns/alm/qm/v0.1/catalog/v0.1" xmlns:ns18="http://jazz.net/xmlns/alm/qm/v0.1/tsl/v0.1/" xmlns:ns20="http://jazz.net/xmlns/alm/qm/styleinfo/v0.1/" xmlns:ns21="http://www.w3.org/1999/XSL/Transform">
    <ns4:title>'''+title+'''</ns4:title>
    <ns4:description/>
    <ns2:creationDate>'''+str(now)+'''</ns2:creationDate>    
    <ns6:state ns1:resource="https://rtc.intel.com/rqm0001001/service/com.ibm.rqm.integration.service.IIntegrationService/process-info/_j9qrIlssEeaEZsWgenb8Uw/workflowstate/com.ibm.rqm.process.testcase.workflow/com.ibm.rqm.planning.common.new">com.ibm.rqm.planning.common.new</ns6:state>
    <ns4:creator ns1:resource="https://rtc.intel.com/jts/resource/itemName/com.ibm.team.repository.Contributor/rskhandx">'''+creator+'''</ns4:creator>
    <ns6:owner>'''+owner+'''</ns6:owner>
    <ns2:locked>false</ns2:locked>
    <ns2:weight>100</ns2:weight>
    <ns2:priority ns1:resource="https://rtc.intel.com/rqm0001001/service/com.ibm.rqm.integration.service.IIntegrationService/process-info/_j9qrIlssEeaEZsWgenb8Uw/priority/literal.priority.101">literal.priority.101</ns2:priority>
    <ns2:suspect>false</ns2:suspect>
    <ns2:variables/>
    <ns2:template href="https://rtc.intel.com/rqm0001001/service/com.ibm.rqm.integration.service.IIntegrationService/resources/IOTG+PED+Central+%28Test+Management%29/template/testcase/com.ibm.rqm.planning.templates.testcase.default"/>
    <ns2:component href="https://rtc.intel.com/rqm0001001/service/com.ibm.rqm.integration.service.IIntegrationService/resources/IOTG+PED+Central+%28Test+Management%29/component/_kvNc0VssEeaEZsWgenb8Uw"/>
    </ns2:testcase> '''
    f.write(s)
    f.close()
    return f

def postTestCasetoRQM():
    os.chdir(r'C:\Users\rskhandx\Documents\Workspace\Mutiara\automation\rqmutility')    
    cmd = 'java -jar RQMUrlUtility.jar -command POST  -user rskhandx -password Sharma@2018 -filepath "'+os.getcwd()+'\\testcaseCreate.xml" -url "https://rtc.intel.com/rqm0001001/service/com.ibm.rqm.integration.service.IIntegrationService/resources/IOTG PED Central (Test Management)/testcase/" '
    print cmd
    p = subprocess.check_output(cmd)
    time.sleep(10)        
    return p

def createMutiaraPostTestCaseToRQMView(request):       
    mform = MutiaraCreatePostCaseToRQM(request.POST)
    context_dict = {}     
    if request.method == 'POST':
        if mform.is_valid():
            title = request.POST.get('title')            
            creator = request.POST.get('creator')            
            owner = request.POST.get('owner')                                
            mform.save()                        
            createRQMTestCaseUtility(title,creator,owner)
            time.sleep(5)
            tc = postTestCasetoRQM()
            context_dict['tc'] = tc
            return render(request,'createTestCase.html',context_dict)
        else:
            return HttpResponse('Form is not valid')
    return render(request,'createTestCaseinRQM.html',{'form':mform})

def createMutiaraTestPlanView(request):  
    form = MutiaraTestPlan(request.POST)  
    mform = MutiaraCreateTestPlanModel(request.POST)
    if request.method == 'POST':
        if mform.is_valid():
            mform.save()            
            return render(request,'testingIndex.html',{'form':mform})
        else:
            return HttpResponse('Form is not valid')
    return render(request,'createTestPlanInMutiara.html',{'form':form})

def createMutiaraTestCasesView(request):  
    form = MutiaraTestCases(request.POST)  
    mform = MutiaraCreateTestCases(request.POST)
    if request.method == 'POST':
        if mform.is_valid():
            mform.save()            
            return render(request,'testingIndex.html',{'form':mform})
        else:
            return HttpResponse('Form is not valid')
    return render(request,'createTestCaseInMutiara.html',{'form':form})



