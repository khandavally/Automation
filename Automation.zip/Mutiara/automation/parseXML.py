'''
Created on Jan 25, 2018

@author: rskhandx
'''
from xml.etree import ElementTree
import pyRXPU
import pprint


with open('gettestcases.xml', 'rt') as f:
    tree = ElementTree.parse(f)
    a = tree.getiterator('feed')
    print a

e = ElementTree.parse('gettestcases.xml').getroot()

for atype in e.findall('feed'):
    print(atype.get('title'))

#print tree
#for node in tree.iter():
#    print 'Tag: ',type(node.tag)    
#    print 'Attributes: ',type(node.attrib)
    
        
def parseTestCaseXML():
    parser = pyRXPU.Parser()
    parser.XMLNamespaces = 2
    doc_source = open('gettestcases.xml').read()
    doc = parser.parse(doc_source)
    print type(doc)
    for items in doc:
        pprint.pprint(items)        
        print type(items)            