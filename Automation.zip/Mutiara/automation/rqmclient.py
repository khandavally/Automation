'''
Created on Jan 25, 2018

@author: rskhandx
'''
import os
import subprocess
import time

class RqmClient(object):
    '''
    classdocs
    '''

    def __init__(self, cmd,user,pwd,filepath,url):
        '''
        Constructor
        '''
        self.cmd = cmd
        self.user = user
        self.pwd = pwd
        self.filepath = filepath
        self.url = url
        
    def rqmPostTestPlan(self):
        cmd = 'java -jar RQMUrlUtility.jar -command '+self.cmd+' -user '+self.user+' -password '+self.pwd+' -filepath '+self.filepath+' -url ' +self.url+'\n'
        print cmd
        p = subprocess.check_output(cmd)
        time.sleep(10)        
        return p
    
    def rqmGetTestPlan(self):
        cmd = 'java -jar RQMUrlUtility.jar -command '+self.cmd+' -user '+self.user+' -password '+self.pwd+' -filepath '+self.filepath+' -url ' +self.url+'\n'
        print cmd
        p = subprocess.check_output(cmd)
        time.sleep(10)        
        return p
    
    def rqmPostTestCase(self):
        cmd = 'java -jar RQMUrlUtility.jar -command '+self.cmd+' -user '+self.user+' -password '+self.pwd+' -filepath '+self.filepath+' -url ' +self.url+'\n'
        print cmd
        p = subprocess.check_output(cmd)
        time.sleep(10)        
        return p
    
    def rqmGetTestCase(self):
        cmd = 'java -jar RQMUrlUtility.jar -command '+self.cmd+' -user '+self.user+' -password '+self.pwd+' -filepath '+self.filepath+' -url ' +self.url+'\n'
        print cmd
        p = subprocess.check_output(cmd)
        time.sleep(10)        
        return p
    


a = RqmClient('POST','rskhandx','Sharma@2018',+'"'+os.getcwd()+'\\rqmutility\\testcase.xml"','"https://rtc.intel.com/rqm0001001/service/com.ibm.rqm.integration.service.IIntegrationService/resources/IOTG PED Central (Test Management)/testcase/"')
b = RqmClient('GET','rskhandx','Sharma@2018',+'"'+os.getcwd()+'\\rqmutility\\gettestcase.xml"','"https://rtc.intel.com/rqm0001001/service/com.ibm.rqm.integration.service.IIntegrationService/resources/IOTG PED Central (Test Management)/testcase/"')    
print a.rqmPostTestCase()
print b.rqmGetTestCase()


