import os
from automation.copyModules import copyTestFiles
import time


def runBuildModule():
    print os.getcwd()
    copyTestFiles()
    time.sleep(5)
    cmd = 'wmic /node:"PGISGLAB106" /user:"PGISGLAB106\\admin" /password:"intel@123" process call create "cmd /c C:\Python27\python.exe \\\PGISGLAB106\\Users\\Public\\Documents\\SharedPath\\flash_dir\\efipowerOn.py"'
    print cmd
    p = os.system(cmd)
    print p

def runFlashModule():
    pass

def runEFITestCaseModule():
    pass


runBuildModule()